/**
* Marlin 3D nyomtató firmware
 * Szerzői jog (c) 2020 MarlinFirmware [https://github.com/MarlinFirmware/Marlin]
 *
 * Sprinter és grbl alapján.
 * Szerzői jog (c) 2011 Camiel Gubbels / Erik van der Zalm
 *
 * Ez a program ingyenes szoftver: terjesztheti és / vagy módosíthatja
 * a GNU Általános Nyilvános Licenc feltételei szerint, a
 * a Free Software Foundation, vagy a licenc 3. verziója, vagy
 * (választása szerint) bármilyen későbbi verzió.
 *
 * Ezt a programot abban a reményben terjesztik, hogy hasznos lesz,
 * de semmiféle jótállás nélkül; még a
 * FORGALMAZHATÓSÁG ÉS FITNESSESSÉG KÜLÖNLEGES CÉLRA. Lásd a
 * A GNU Általános Nyilvános Licenc részletekért.
 *
 * Meg kellett volna kapnia a GNU Általános Nyilvános Licenc példányát
 * a programmal együtt. Ha nem, olvassa el a <http://www.gnu.org/licenses/> oldalt.
 *
 *
 */
#pragma once

/**
 * Alapvető beállítások, például:
 * 
 * - az elektronika típusa
 * - A hőmérséklet-érzékelő típusa
 * - A nyomtató geometriája
 * - Endstop konfiguráció
 * - LCD vezérlő
 * - További szolgáltatások
 * 
 * A speciális beállítások a Configuration_adv.h webhelyen találhatók
 *
 */
#define CONFIGURATION_H_VERSION 020005

//===========================================================================
//============================= Az első lépések =============================
//===========================================================================

/**
 * Itt található néhány általános link a gép kalibrálásához:
 *
 * http://reprap.org/wiki/Calibration
 * http://youtu.be/wAL9d7FgInk
 * http://calculator.josefprusa.cz
 * http://reprap.org/wiki/Triffid_Hunter%27s_Calibration_Guide
 * http://www.thingiverse.com/thing:5573
 * https://sites.google.com/site/repraplogphase/calibration-of-your-reprap
 * http://www.thingiverse.com/thing:298812
 */

//===========================================================================
//============================= DELTA nyomtató ==============================
//===========================================================================
// Delta nyomtató esetén kezdje meg a konfigurációs fájlok egyikével
// config / példa / delta könyvtár, és testreszabható a gépére.
//

//===========================================================================
//============================= SCARA nyomtató ==============================
//===========================================================================
// SCARA nyomtató esetén kezdje meg a konfigurációs fájlokkal a
// config / példák / SCARA és testreszabható a gépéhez.
//

// @ szakasz információ

// Ennek az építkezésnek a szerzői adatai kinyomtatódnak a gazdagépre indítás és M115 során
#define STRING_CONFIG_H_AUTHOR "(nincs, alapértelmezett konfiguráció)" // Ki változtatta meg.
// # definiálja a CUSTOM_VERSION_FILE Version.h // elérési útját a gyökérkönyvtárból (idézetek nélkül)

/**
 * *** A VENDOROK, KÉRJÜK OLVASSA EL  ***
 *
 * Marlin allows you to add a custom boot image for Graphical LCDs.
 * With this option Marlin will first show your custom screen followed
 * by the standard Marlin logo with version number and web URL.
 *
 * We encourage you to take advantage of this new feature and we also
 * respectfully request that you retain the unmodified Marlin boot screen.
 */

// Mutassa meg a Marlin rendszerindító képernyőjét indításkor. ** TERMELÉSI LEHETŐSÉG **
#define SHOW_BOOTSCREEN

// Mutassa meg a bitképet a Marlin / _Bootscreen.h fájlban indításkor.
//#define SHOW_CUSTOM_BOOTSCREEN

// Mutassa meg a bitképet a Marlin / _Statusscreen.h fájlban az állapotképernyőn.
//#define CUSTOM_STATUS_SCREEN_IMAGE

// @szekciógép

/**
 * Válassza ki a táblán a soros portot, amelyet a gazdagéppel történő kommunikációhoz használ.
 * Ez lehetővé teszi a vezeték nélküli adapterek (például) a nem alapértelmezett porttűs csatlakoztatását.
 * A -1 soros port az USB-vel emulált soros port, ha rendelkezésre áll.
 * Megjegyzés: Az első soros portot (-1 vagy 0) az Arduino rendszerbetöltő mindig használja.
 *
 * :[-1, 0, 1, 2, 3, 4, 5, 6, 7]
 */
#define SERIAL_PORT 0

/**
 * Válasszon egy másodlagos soros portot a táblán, amelyet a gazdaval történő kommunikációhoz használ.
 * :[-1, 0, 1, 2, 3, 4, 5, 6, 7]
 */
//#define SERIAL_PORT_2 -1

/**
 * Ez a beállítás határozza meg a nyomtató kommunikációs sebességét.
 *
 * A 250000 a legtöbb esetben működik, de kipróbálhat alacsonyabb sebességet is
 * A kiszolgálónyomtatás során általában kiszorul.
 * Kipróbálhat 1000000-at az SD-fájl átvitelének felgyorsítása érdekében.
 *
 * :[2400, 9600, 19200, 38400, 57600, 115200, 250000, 500000, 1000000]
 */
#define BAUDRATE 250000

// Engedélyezze a Bluetooth soros interfészt az AT90USB készülékeken
//#define BLUETOOTH

// Válasszon egy nevet a boards.h közül, amely megfelel a beállításának
#ifndef MOTHERBOARD
  #define MOTHERBOARD BOARD_RAMPS_14_EFB
#endif

// Az LCD kijelzőn megjelenik a "Kész" üzenet és az Info menü
//#define CUSTOM_MACHINE_NAME "3D Printer"

// A nyomtató egyedi azonosítója, amelyet egyes programok használnak a gépek megkülönböztetésére.
// Válassza ki a sajátját, vagy használjon olyan szolgáltatást, mint a http://www.uuidgenerator.net/version4
//#define MACHINE_UUID "00000000-0000-0000-0000-000000000000"

// @section extruder

// Ez határozza meg az extruderek számát
// :[1, 2, 3, 4, 5, 6, 7, 8]
#define EXTRUDERS 1

// Általánosságban várható filament átmérő (1,75, 2,85, 3,0, ...). Volumetrikus, filament szélesség-érzékelőhöz stb.
#define DEFAULT_NOMINAL_FILAMENT_DIA 1.75

// Cyclops vagy bármilyen "multi-extruder" esetén, amelyek egyetlen fúvókát osztanak meg.
//#define SINGLENOZZLE

/**
 * Průša MK2 egy fúvóka multi-anyag multiplexer és változatai.
 *
 * Ez az eszköz lehetővé teszi a vezérlőpulton lévő egy léptető meghajtó vezetését
 * két-nyolc léptetőmotor, egyenként, megfelelő módon
 * extruderek számára.
 *
 * Ez az opció csak a multiplexer számára engedélyezi a szerszámcserét.
 * Az egyéni E mozgalmak konfigurálásának további lehetőségei még függőben vannak.
 */
//#define MK2_MULTIPLEXER
#if ENABLED(MK2_MULTIPLEXER)
  // Szükség esetén felülbírálja az alapértelmezett DIO választócsapokat.
  // Egyes pin-fájlok alapértelmezésként biztosíthatják ezeket a pineket.
  //#define E_MUX0_PIN 40  // Always Required
  //#define E_MUX1_PIN 42  // Needed for 3 to 8 inputs
  //#define E_MUX2_PIN 44  // Needed for 5 to 8 inputs
#endif

/**
 * Prusa Multi-Material Unit v2
 *
 *A nyomtatófej leállításához NOZZLE_PARK_FEATURE szükséges, ha az MMU egység meghibásodik.
 * Requires EXTRUDERS = 5
 *
 * További konfigurációért lásd: Configuration_adv.h
 */
//#define PRUSA_MMU2

// Kettős extruder, amely egylépcsős motort használ
//#define SWITCHING_EXTRUDER
#if ENABLED(SWITCHING_EXTRUDER)
  #define SWITCHING_EXTRUDER_SERVO_NR 0
  #define SWITCHING_EXTRUDER_SERVO_ANGLES { 0, 90 } // Az E0, E1 [, E2, E3] szögei
  #if EXTRUDERS > 3
    #define SWITCHING_EXTRUDER_E23_SERVO_NR 1
  #endif
#endif

// Kettős fúvóka, amely szervomotorral fújja le vagy engedi le a fúvókákat (vagy mindkettőt)
//#define SWITCHING_NOZZLE
#if ENABLED(SWITCHING_NOZZLE)
  #define SWITCHING_NOZZLE_SERVO_NR 0
  //#define SWITCHING_NOZZLE_E1_SERVO_NR 1          //  Ha két szervót használ, akkor a második indexét
  #define SWITCHING_NOZZLE_SERVO_ANGLES { 0, 90 }   // Az E0, E1 (egyetlen szervo) vagy leengedett / emelt (duális szervo) szögek
#endif

/**
 * Két különálló X-kocsi extruderekkel, amelyek csatlakoznak egy mozgó alkatrészhez
 * szolenoid dokkoló mechanizmuson keresztül. Szükséges a SOL1_PIN és a SOL2_PIN.
 */
//#define PARKING_EXTRUDER

/**
 * Két különálló X-kocsi extruderekkel, amelyek csatlakoznak egy mozgó alkatrészhez
 * mágneses dokkolómechanizmuson keresztül, mozgások nélkül és mágnesszelep nélkül
 *
 * project   : https://www.thingiverse.com/thing:3080893
 * movements : https://youtu.be/0xCEiG9VS3k
 *             https://youtu.be/Bqbcs0CU2FE
 */
//#define MAGNETIC_PARKING_EXTRUDER

#if EITHER(PARKING_EXTRUDER, MAGNETIC_PARKING_EXTRUDER)

  #define PARKING_EXTRUDER_PARKING_X { -78, 184 }     // X pozíció az extruderek parkolására
  #define PARKING_EXTRUDER_GRAB_DISTANCE 1            // (mm) Távolság a parkolási ponton való túljutáshoz az extruder megragadásához
  //#define MANUAL_SOLENOID_CONTROL                   // A dokkoló mágnesszelepek kézi vezérlése az M380 S / M381 készülékkel

  #if ENABLED(PARKING_EXTRUDER)

    #define PARKING_EXTRUDER_SOLENOIDS_INVERT           // Ha engedélyezve van, akkor a mágnesszelepet NEM mágnesezjük alkalmazott feszültséggel
    #define PARKING_EXTRUDER_SOLENOIDS_PINS_ACTIVE LOW  // LOW vagy HIGH pin jel energiát ad a tekercsről
    #define PARKING_EXTRUDER_SOLENOIDS_DELAY 250        // (ms) Késleltetés a mágneses mezőre. Nincs késés, ha 0 vagy nincs meghatározva.
    //#define MANUAL_SOLENOID_CONTROL                   // A dokkoló mágnesszelepek kézi vezérlése az M380 S / M381 készülékkel

  #elif ENABLED(MAGNETIC_PARKING_EXTRUDER)

    #define MPE_FAST_SPEED      9000      // (mm/m) Az utolsó távolságpont előtti haladás sebessége
    #define MPE_SLOW_SPEED      4500      // (mm/m) Sebesség az utolsó távolsághoz történő parkoláshoz és párhoz
    #define MPE_TRAVEL_DISTANCE   10      // (mm) Utolsó távolsági pont
    #define MPE_COMPENSATION       0      // Offset Kompenzáció -1, 0, 1 (szorzó), csak a kapcsoláshoz

  #endif

#endif

/**
 * Az eszközfej váltása
 *
 * Támogatás cserélhető és dokkolható eszközfejekre, például
 * az E3D eszközváltó. Az eszközfejeket szervóval rögzítik.
 */
//#define SWITCHING_TOOLHEAD

/**
 * Mágneses kapcsoló eszközfej
 *
 * Támogassa a cserélhető és dokkolható szerszámfejeket mágneses készülékkel
 * dokkoló mechanizmus mozgás és szervo nélkül.
 */
//#define MAGNETIC_SWITCHING_TOOLHEAD

/**
 * Elektromágneses kapcsoló szerszámfej
 *
 * Parkolás a CoreXY / HBot kinematika számára.
 * A szerszámfejeket az egyik szélén parkolják le és elektromágnesekkel tartják.
 * Több mint 2 eszközfejet támogat. Lásd: https://youtu.be/JolbsAKTKf4
 */
//#define ELECTROMAGNETIC_SWITCHING_TOOLHEAD

#if ANY(SWITCHING_TOOLHEAD, MAGNETIC_SWITCHING_TOOLHEAD, ELECTROMAGNETIC_SWITCHING_TOOLHEAD)
  #define SWITCHING_TOOLHEAD_Y_POS          235         // (mm) a szerszámfej-dokkoló helyzet Y
  #define SWITCHING_TOOLHEAD_Y_SECURITY      10         // (mm) Biztonsági távolság Y tengely
  #define SWITCHING_TOOLHEAD_Y_CLEAR         60         // (mm) A dokk minimális távolsága az akadálymentes X tengelyen
  #define SWITCHING_TOOLHEAD_X_POS          { 215, 0 }  // (mm) X pozíciók az extruderek parkolására
  #if ENABLED(SWITCHING_TOOLHEAD)                       
    #define SWITCHING_TOOLHEAD_SERVO_NR       2         // A szervo csatlakozó indexe
    #define SWITCHING_TOOLHEAD_SERVO_ANGLES { 0, 180 }  // (fok) zárási, kinyitási szögek
  #elif ENABLED(MAGNETIC_SWITCHING_TOOLHEAD)            
    #define SWITCHING_TOOLHEAD_Y_RELEASE      5         // (mm) Biztonsági távolság Y tengely
    #define SWITCHING_TOOLHEAD_X_SECURITY   { 90, 150 } // (mm) Biztonsági távolság X tengely (T0, T1)
    //#define PRIME_BEFORE_REMOVE                       // A dokkolóból való kioldás előtt töltse fel a fúvókát
    #if ENABLED(PRIME_BEFORE_REMOVE)                    
      #define SWITCHING_TOOLHEAD_PRIME_MM           20  // (mm) Az extruder primer hossza
      #define SWITCHING_TOOLHEAD_RETRACT_MM         10  // (mm) Visszahúzás az alapozás után
      #define SWITCHING_TOOLHEAD_PRIME_FEEDRATE    300  // (mm / m) Az extruder elsődleges előtolása
      #define SWITCHING_TOOLHEAD_RETRACT_FEEDRATE 2400  // (mm / m) Az extruder visszahúzó előtolása
    #endif                                              
  #elif ENABLED(ELECTROMAGNETIC_SWITCHING_TOOLHEAD)     
    #define SWITCHING_TOOLHEAD_Z_HOP          2         // (mm) Z emelés a váltáshoz
  #endif
#endif

/**
 * "Keverő extruder"
 * - M163 és M164 G-kódot ad hozzá az aktuális keverési tényezők beállításához és "beiktatásához".
 * - Meghosszabbítja a lépési rutinokat a többlépcső mozgatásához a keverék arányában.
 * - Opcionális támogatás a Repetier Firmware 'M164 S <index>' támogató virtuális eszközeire.
 * - Ez a megvalósítás legfeljebb két keverő extrudert támogat.
 * - Engedélyezze a DIRECT_MIXING_IN_G1-et az M165-hez és a keverést a G1-ben (a Pia Taubert referencia-megvalósításából).
 */
//#define MIXING_EXTRUDER
#if ENABLED(MIXING_EXTRUDER)
  #define MIXING_STEPPERS 2        // Lépcsők száma a keverő extruderben
  #define MIXING_VIRTUAL_TOOLS 16  // Használja a virtuális eszköz módszert az M163 és M164 típusokhoz
  //#define DIRECT_MIXING_IN_G1    // Engedélyezze az ABCDHI keverési tényezőit a G1 mozgási parancsokban
  //#define GRADIENT_MIX           // Támogatás a gradienskeveréshez az M166-tal és az LCD-vel
  #if ENABLED(GRADIENT_MIX)
    //#define GRADIENT_VTOOL       // M166 T hozzáadása V-szerszám-index használatához Gradient alias-ként
  #endif
#endif

// Az extruderek eltolása (nem egyezés, ha egynél többet használ, és a firmware-re támaszkodik a helyzetbe, ha változik).
// Az eltolásnak X = 0-nak, Y = 0-nak kell lennie az extruder 0 hotendje esetén (alapértelmezett extruder).
// A többi melegítő számára a távolság az extrudertől 0 forró.
//#define HOTEND_OFFSET_X { 0.0, 20.00 } // (mm) relative X-offset az egyes nozzlenél
//#define HOTEND_OFFSET_Y { 0.0, 5.00 }  // (mm) relative Y-offset az egyes nozzlenél
//#define HOTEND_OFFSET_Z { 0.0, 0.00 }  // (mm) relative Z-offset az egyes nozzlenél

// @section machine

/**
 * Tápegység vezérlés
 *
 * Engedélyezze és csatlakoztassa az áramellátást a PS_ON_PIN-hez.
 * Adja meg, hogy az áramellátás aktív HIGH vagy aktív LOW.
 */
//#define PSU_CONTROL
//#define PSU_NAME "Power Supply"

#if ENABLED(PSU_CONTROL)
  #define PSU_ACTIVE_HIGH false     // Az ATX-hez állítsa a „false” értéket, az X-Box esetében „true” -ot

  //#define PSU_DEFAULT_OFF         // Tartsa ki az áramellátást, amíg közvetlenül nem engedélyezi az M80-at
  //#define PSU_POWERUP_DELAY 100   // (ms) késleltetést a PSU teljes melegítésére történő felmelegítéséhez

  //#define AUTO_POWER_CONTROL      // Engedélyezze a PS_ON PIN automatikus vezérlését
  #if ENABLED(AUTO_POWER_CONTROL)
    #define AUTO_POWER_FANS         // Kapcsolja be a PSU-t, ha a ventillátoroknak áramra van szükségük
    #define AUTO_POWER_E_FANS
    #define AUTO_POWER_CONTROLLERFAN
    #define AUTO_POWER_CHAMBER_FAN
    //#define AUTO_POWER_E_TEMP        50 // (° C) Kapcsolja be a PSU-t ezen a hőmérsékleten
    //#define AUTO_POWER_CHAMBER_TEMP  30 // (° C) Kapcsolja be a PSU-t ezen a hőmérsékleten
    #define POWER_TIMEOUT 30
  #endif
#endif

// @section hőmérséklete

//===========================================================================
//========================= Hőmérséklet beállítások =========================
//===========================================================================

/**
 * --NORMAL IS 4.7kohm PULLUP!--  Az 1kohm pullup használható hotend szenzoron, megfelelő ellenállás és asztal használatával
 *
 * Választható Hőmérséklet-érzékelők:
 *
 *    -5 : PT100 / PT1000 with MAX31865 	(csak a 0-1 érzékelők számára)
 *    -3 : thermocouple with MAX31855 		(csak a 0-1 érzékelők számára)
 *    -2 : thermocouple with MAX6675 		(csak a 0-1 érzékelők számára)
 *    -4 : thermocouple with AD8495
 *    -1 : thermocouple with AD595
 *     0 : not used
 *     1 : 100k thermistor - best choice for EPCOS 100k (4.7k pullup)
 *   331 : (3.3V scaled thermistor 1 table for MEGA)
 *   332 : (3.3V scaled thermistor 1 table for DUE)
 *     2 : 200k thermistor - ATC Semitec 204GT-2 (4.7k pullup)
 *   202 : 200k thermistor - Copymaster 3D
 *     3 : Mendel-parts thermistor (4.7k pullup)
 *     4 : 10k thermistor !! do not use it for a hotend. It gives bad resolution at high temp. !!
 *     5 : 100K thermistor - ATC Semitec 104GT-2/104NT-4-R025H42G (Used in ParCan & J-Head) (4.7k pullup)
 *   501 : 100K Zonestar (Tronxy X3A) Thermistor
 *   512 : 100k RPW-Ultra hotend thermistor (4.7k pullup)
 *     6 : 100k EPCOS - Not as accurate as table 1 (created using a fluke thermocouple) (4.7k pullup)
 *     7 : 100k Honeywell thermistor 135-104LAG-J01 (4.7k pullup)
 *    71 : 100k Honeywell thermistor 135-104LAF-J01 (4.7k pullup)
 *     8 : 100k 0603 SMD Vishay NTCS0603E3104FXT (4.7k pullup)
 *     9 : 100k GE Sensing AL03006-58.2K-97-G1 (4.7k pullup)
 *    10 : 100k RS thermistor 198-961 (4.7k pullup)
 *    11 : 100k beta 3950 1% thermistor (4.7k pullup)
 *    12 : 100k 0603 SMD Vishay NTCS0603E3104FXT (4.7k pullup) (calibrated for Makibox hot bed)
 *    13 : 100k Hisens 3950  1% up to 300°C for hotend "Simple ONE " & "Hotend "All In ONE"
 *    15 : 100k thermistor calibration for JGAurora A5 hotend
 *    18 : ATC Semitec 204GT-2 (4.7k pullup) Dagoma.Fr - MKS_Base_DKU001327
 *    20 : Pt100 with circuit in the Ultimainboard V2.x with 5v excitation (AVR)
 *    21 : Pt100 with circuit in the Ultimainboard V2.x with 3.3v excitation (STM32 \ LPC176x....)
 *   201 : Pt100 with circuit in Overlord, similar to Ultimainboard V2.x
 *    60 : 100k Maker's Tool Works Kapton Bed Thermistor beta=3950
 *    61 : 100k Formbot / Vivedino 3950 350C thermistor 4.7k pullup
 *    66 : 4.7M High Temperature thermistor from Dyze Design
 *    67 : 450C thermistor from SliceEngineering
 *    70 : the 100K thermistor found in the bq Hephestos 2
 *    75 : 100k Generic Silicon Heat Pad with NTC 100K MGB18-104F39050L32 thermistor
 *    99 : 100k thermistor with a 10K pull-up resistor (found on some Wanhao i3 machines)
 *
 *       1k ohm pullup tables - This is atypical, and requires changing out the 4.7k pullup for 1k.
 *                              (de nagyobb pontosságot és stabilabb PID-t biztosít)
 *    51 : 100k thermistor - EPCOS (1k pullup)
 *    52 : 200k thermistor - ATC Semitec 204GT-2 (1k pullup)
 *    55 : 100k thermistor - ATC Semitec 104GT-2 (Used in ParCan & J-Head) (1k pullup)
 *
 *  1047 : Pt1000 with 4k7 pullup
 *  1010 : Pt1000 with 1k pullup (non standard)
 *   147 : Pt100 with 4k7 pullup
 *   110 : Pt100 with 1k pullup (non standard)
 *
 *  1000 : Custom - Specify parameters in Configuration_adv.h
 *
 *          Használja ezeket tesztelési vagy fejlesztési célokra. SOHA ne gyártógépeknél.
 *   998 : Dummy Table that ALWAYS reads 25°C or the temperature defined below.
 *   999 : Dummy Table that ALWAYS reads 100°C or the temperature defined below.
 */
#define TEMP_SENSOR_0 1
#define TEMP_SENSOR_1 0
#define TEMP_SENSOR_2 0
#define TEMP_SENSOR_3 0
#define TEMP_SENSOR_4 0
#define TEMP_SENSOR_5 0
#define TEMP_SENSOR_6 0
#define TEMP_SENSOR_7 0
#define TEMP_SENSOR_BED 0
#define TEMP_SENSOR_PROBE 0
#define TEMP_SENSOR_CHAMBER 0

// A próbabábu termisztorának állandó hőmérséklet-leolvasásai, a 998-as és a 999-es készülékekhez
#define DUMMY_THERMISTOR_998_VALUE 25
#define DUMMY_THERMISTOR_999_VALUE 100

// Használja az 1. hőmérséklet-érzékelőt redundáns érzékelőként a 0. érzékelővel. Ha a leolvasások
// a két érzékelőtől túlságosan különbözik a nyomtatás meg fog szakadni.
//#define TEMP_SENSOR_1_AS_REDUNDANT
#define MAX_REDUNDANT_TEMP_SENSOR_DIFF 10

#define TEMP_RESIDENCY_TIME     10  // (másodperc) Ideje megvárni, hogy a hotend "elszámoljon" az M109-ben
#define TEMP_WINDOW              1  // (° C) Hőmérsékleti közelség az "elért hőmérséklet" időzítőnél
#define TEMP_HYSTERESIS          3  // (° C) A hőmérsékleti közelséget a célhoz "elég közel" tekintik

#define TEMP_BED_RESIDENCY_TIME 10  // (másodpercben) Ideje várni az ágyra, hogy "letelepedjen" az M190-ben
#define TEMP_BED_WINDOW          1  // (° C) Hőmérsékleti közelség az "elért hőmérséklet" időzítőnél
#define TEMP_BED_HYSTERESIS      3  // (° C) A hőmérsékleti közelséget a célhoz "elég közel" tekintik

// Ezen a hőmérsékleten a fűtés kikapcsol
// mert valószínűleg egy eltört termisztor huzalt jelez.
#define HEATER_0_MINTEMP   5
#define HEATER_1_MINTEMP   5
#define HEATER_2_MINTEMP   5
#define HEATER_3_MINTEMP   5
#define HEATER_4_MINTEMP   5
#define HEATER_5_MINTEMP   5
#define HEATER_6_MINTEMP   5
#define HEATER_7_MINTEMP   5
#define BED_MINTEMP        5

// Ezen a hőmérsékleten a fűtés kikapcsol.
// Ez megóvhatja az alkatrészeket a túlmelegedéstől, de NEM a rövidzárlattól és a hibáktól.
// (Használjon MINTEMP-t a termisztor rövid / meghibásodás elleni védelemhez.)
#define HEATER_0_MAXTEMP 275
#define HEATER_1_MAXTEMP 275
#define HEATER_2_MAXTEMP 275
#define HEATER_3_MAXTEMP 275
#define HEATER_4_MAXTEMP 275
#define HEATER_5_MAXTEMP 275
#define HEATER_6_MAXTEMP 275
#define HEATER_7_MAXTEMP 275
#define BED_MAXTEMP      150

//===========================================================================
//============================= PID Beállítások ================================
//===========================================================================
// PID hangolási útmutató itt: http://reprap.org/wiki/PID_Tuning

// Kommentálja a következő sort a PID letiltásához és a bang-bang engedélyezéséhez.
#define PIDTEMP
#define BANG_MAX 255     // Korlátozza a fúvóka áramát bang-bang módban; 255 = teljes áram
#define PID_MAX BANG_MAX // A fúvóka áramát korlátozza, amíg a PID aktív (lásd alább a PID_FUNCTIONAL_RANGE-t); 255 = teljes áram
#define PID_K1 0.95      // Simító tényező bármely PID hurokban
#if ENABLED(PIDTEMP)
  //#define PID_EDIT_MENU         // PID-szerkesztést adjon az "Advanced Settings" menübe. (~ 700 bájt PROGMEM)
  //#define PID_AUTOTUNE_MENU     // Adja hozzá a PID automatikus hangolását az "Advanced Settings" menübe. (~ 250 bájt PROGMEM)
  //#define PID_DEBUG             // Hibaadatokat küld a soros portra.
  //#define PID_OPENLOOP 1        // A PID-et nyitott hurokba helyezi. Az M104 / M140 a kimeneti teljesítményt 0-ról PID_MAX-ra állítja
  //#define SLOW_PWM_HEATERS      // nagyon alacsony frekvenciájú (kb. 0,125Hz = 8s) PWM-et, minimális állapotideje körülbelül 1 s, amely relé által hajtott fűtőkészülékeknél hasznos
  //#define PID_PARAMS_PER_HOTEND // külön-külön PID paramétereket használ minden egyes extruder számára (nem megeggyező extruderek esetén hasznos)
                                  // Set/Get kóddal: M301 E [extruder száma, 0-2]
  #define PID_FUNCTIONAL_RANGE 10 // Ha a hőmérsékleti különbség a célhőmérséklet és a tényleges hőmérséklet között
                                  // több mint PID_FUNCTIONAL_RANGE, akkor a PID kikapcsol és a fűtőberendezést min / max értékre állítja.

  // Ha egy előre konfigurált hotend-t használ, akkor az értékhalmazok egyikét is felhasználhatja, anélkül, hogy megismételné őket

  // Ultimaker
  #define DEFAULT_Kp 22.2
  #define DEFAULT_Ki 1.08
  #define DEFAULT_Kd 114

  // MakerGear
  //#define DEFAULT_Kp 7.0
  //#define DEFAULT_Ki 0.1
  //#define DEFAULT_Kd 12

  // Mendel Parts V9 on 12V
  //#define DEFAULT_Kp 63.0
  //#define DEFAULT_Ki 2.25
  //#define DEFAULT_Kd 440

#endif // PIDTEMP

//===========================================================================
//====================== PID > Ágy hőmérséklet-szabályozása =================
//===========================================================================

/**
 * PID ágyfűtés
 *
 * Ha ez az opció engedélyezett, állítsa be az alábbi PID-állandókat.
 * Ha ez az opció le van tiltva, akkor a bang-bang kerül felhasználásra, és a BED_LIMIT_SWITCHING engedélyezi a hiszterézist.
 *
 * A PID frekvencia megegyezik az extruder PWM-ével.
 * Ha a PID_dT az alapértelmezett, és helyes a hardverre / konfigurációra, ez azt jelenti, hogy 7.689Hz,
 * ami egy négyzethullám ellenállásos terhelésbe történő bevezetésére alkalmas, és nem jelentősen
 * ütéses FET fűtés. Ez jól működik egy Fotek SSR-10DA szilárdtest relén egy 250 W-os teljesítmény
 * fűtésre. Ha a konfiguráció jelentősen eltér ettől, és nem érti
 * a felmerülő problémákhoz ne használja az ágy PID-t, amíg valaki más nem ellenőrzi, hogy a hardver működik-e.
 */
//#define PIDTEMPBED

//#define BED_LIMIT_SWITCHING

/**
 * Maximális ágy teljesítmény
 * Az ágyszabályozás minden formájára vonatkozik (PID, bang-bang és bang-bang hiszterézissel).
 * Ha bármilyen értékre áll, 255 alatt, engedélyezheti az ágyhoz a PWM formáját, amely elválasztóként működik
 * szóval csak akkor használja, ha nincs rendben a PWM-mel az ágy. (Lásd a PIDTEMPBED engedélyezésének megjegyzését)
 */
#define MAX_BED_POWER 255 // korlátozza az üzemi ciklust az ágyra; 255 = teljes áram

#if ENABLED(PIDTEMPBED)
  //#define MIN_BED_POWER 0
  //#define PID_BED_DEBUG // Hibaadatokat küld a soros portra.

  // 120 V 250W-os szilikon fűtőberendezés 4 mm-es boroszilikátba (MendelMax 1.5+)
  // a FOPDT modelltől - kp = .39 Tp = 405 Tdead = 66, Tc 79,2-re állítva, 0,15 agresszív tényező (vs. 1, 1, 10)
  #define DEFAULT_bedKp 10.00
  #define DEFAULT_bedKi .023
  #define DEFAULT_bedKd 305.4

  // 120 V 250W-os szilikon fűtőberendezés 4 mm-es boroszilikátba (MendelMax 1.5+)
  // pidautotune-ból
  //#define DEFAULT_bedKp 97.1
  //#define DEFAULT_bedKi 1.41
  //#define DEFAULT_bedKd 1675.16

   // TUDJA MEG SAJÁT: "M303 E-1 C8 S90" az automata hangoláshoz az ágyon 90 ° C-on 8 cikluson keresztül.
#endif // PIDTEMPBED

// @section extruder

/**
 * Kerülje el az extrudálást, ha a hőmérséklet az EXTRUDE_MINTEMP alatt van.
 * M302 hozzáadása a minimális extrudálási hőmérséklet beállításához és / vagy forgatáshoz
 * a hideg extrudálás megelőzése és kikapcsolása.
 *
 * *** KIBA... NAGYON AJÁNLOTT, HOGY MEG hagyja ezt az opciót engedélyezni! ***
 */
#define PREVENT_COLD_EXTRUSION
#define EXTRUDE_MINTEMP 170

/**
 * Kerülje el az extrudálást, amely hosszabb, mint az EXTRUDE_MAXLENGTH.
 * Megjegyzés: A Bowden extruderek esetében tegyék ezt elég nagyra, hogy lehetővé tegyék a be- és kirakodást.
 */
#define PREVENT_LENGTHY_EXTRUDE
#define EXTRUDE_MAXLENGTH 200

//===========================================================================
//===================== Termikus túlfutás elleni védelem ====================
//===========================================================================

/**
 * A hővédelem további védelmet nyújt a nyomtatónak a károsodásoktól
 * és a tűztől. A Marlin mindig magában foglalja a biztonságos minimális és maximális hőmérsékleti tartományokat
 * védelmet nyújt a törött vagy levállt termisztor vezeték ellen.
 *
 * A probléma: Ha egy termisztor kiesik, akkor sokkal alacsonyabbat jelenít meg,
 * a levegő hőmérsékletét a szobában, és a firmware megtartja
 * a fűtést bekapcsolva.
 *
 * Ha a "Thermal Runaway" vagy a "Heating failed" hibákat kapja, akkor a
 * A részletek a Configuration_adv.h fájlban hangolhatók
 */

#define THERMAL_PROTECTION_HOTENDS // Hővédelem engedélyezése az összes extruder számára
#define THERMAL_PROTECTION_BED     // A fűtött ágy hővédelmének engedélyezése
#define THERMAL_PROTECTION_CHAMBER // A fűtött kamra hővédelmének engedélyezése

//===========================================================================
//============================ Mechanikai beállítások =======================
//===========================================================================

// @section machine

// Távolítsa el ezen lehetőségek egyikét a CoreXY, CoreXZ vagy CoreYZ kinematics engedélyezéséhez
// vagy a szokásos sorrendben, vagy fordítva
//#define COREXY
//#define COREXZ
//#define COREYZ
//#define COREYX
//#define COREZX
//#define COREZY

//===========================================================================
//============================== Endstop Settings ===========================
//===========================================================================

// @section homingolás

// Itt adja meg az összes végállomás-csatlakozót, amely bármilyen végállomáshoz vagy szondahoz csatlakozik.
// Szinte minden nyomtató tengelyenként egyet fog használni. A szonda a következők közül egyet vagy többet fog használni
// extra csatlakozók. Hagyja meghatározatlanként felhasználva a végtelen és nem szondás célokat.
#define USE_XMIN_PLUG
#define USE_YMIN_PLUG
#define USE_ZMIN_PLUG
//#define USE_XMAX_PLUG
//#define USE_YMAX_PLUG
//#define USE_ZMAX_PLUG

// Az összes végállomás letiltásának engedélyezése a lebegő állapot megakadályozása érdekében
#define ENDSTOPPULLUPS
#if DISABLED(ENDSTOPPULLUPS)
  // Az ENDSTOPPULLUPS letiltása a pullupok egyedi beállításához
  //#define ENDSTOPPULLUP_XMAX
  //#define ENDSTOPPULLUP_YMAX
  //#define ENDSTOPPULLUP_ZMAX
  //#define ENDSTOPPULLUP_XMIN
  //#define ENDSTOPPULLUP_YMIN
  //#define ENDSTOPPULLUP_ZMIN
  //#define ENDSTOPPULLUP_ZMIN_PROBE
#endif

// Az összes végállomás lekapcsolásának engedélyezése a lebegő állapot megakadályozása érdekében
//#define ENDSTOPPULLDOWNS
#if DISABLED(ENDSTOPPULLDOWNS)
  // Kapcsolja ki az ENDSTOPPULLDOWNS elemet a lekérdezések egyéni beállításához
  //#define ENDSTOPPULLDOWN_XMAX
  //#define ENDSTOPPULLDOWN_YMAX
  //#define ENDSTOPPULLDOWN_ZMAX
  //#define ENDSTOPPULLDOWN_XMIN
  //#define ENDSTOPPULLDOWN_YMIN
  //#define ENDSTOPPULLDOWN_ZMIN
  //#define ENDSTOPPULLDOWN_ZMIN_PROBE
#endif

// A mechanikus végállomás COM-mal a földdel és az NC-vel a jelhez "false" értéket használ (a leggyakoribb beállítás).
#define X_MIN_ENDSTOP_INVERTING false // Állítsa be true értékre, hogy megfordítsa az endstop logikáját.
#define Y_MIN_ENDSTOP_INVERTING false // Állítsa be true értékre, hogy megfordítsa az endstop logikáját.
#define Z_MIN_ENDSTOP_INVERTING false // Állítsa be true értékre, hogy megfordítsa az endstop logikáját.
#define X_MAX_ENDSTOP_INVERTING false // Állítsa be true értékre, hogy megfordítsa az endstop logikáját.
#define Y_MAX_ENDSTOP_INVERTING false // Állítsa be true értékre, hogy megfordítsa az endstop logikáját.
#define Z_MAX_ENDSTOP_INVERTING false // Állítsa be true értékre, hogy megfordítsa az endstop logikáját.
#define Z_MIN_PROBE_ENDSTOP_INVERTING false // Állítsa be true értékre, hogy megfordítsa a szonda logikáját.

/**
 * Léptető illesztőprogramok
 *
 * Ezek a beállítások lehetővé teszik Marlin számára, hogy beállítsa a léptető illesztőprogram időzítését, és lehetővé tegye a speciális lehetőségeket a
 * Stepper meghajtók, amelyek támogatják őket. Az időzítési lehetőségeket felülírhatja a Configuration_adv.h fájlban is.
 *
 * Az A4988 nem feltételezett illesztőprogramok esetén feltételezhető.
 *
 * Options: A4988, A5984, DRV8825, LV8729, L6470, L6474, POWERSTEP01,
 *          TB6560, TB6600, TMC2100,
 *          TMC2130, TMC2130_STANDALONE, TMC2160, TMC2160_STANDALONE,
 *          TMC2208, TMC2208_STANDALONE, TMC2209, TMC2209_STANDALONE,
 *          TMC26X,  TMC26X_STANDALONE,  TMC2660, TMC2660_STANDALONE,
 *          TMC5130, TMC5130_STANDALONE, TMC5160, TMC5160_STANDALONE
 * :['A4988', 'A5984', 'DRV8825', 'LV8729', 'L6470', 'L6474', 'POWERSTEP01', 'TB6560', 'TB6600', 'TMC2100', 'TMC2130', 'TMC2130_STANDALONE', 'TMC2160', 'TMC2160_STANDALONE', 'TMC2208', 'TMC2208_STANDALONE', 'TMC2209', 'TMC2209_STANDALONE', 'TMC26X', 'TMC26X_STANDALONE', 'TMC2660', 'TMC2660_STANDALONE', 'TMC5130', 'TMC5130_STANDALONE', 'TMC5160', 'TMC5160_STANDALONE']
 */
//#define X_DRIVER_TYPE  A4988
//#define Y_DRIVER_TYPE  A4988
//#define Z_DRIVER_TYPE  A4988
//#define X2_DRIVER_TYPE A4988
//#define Y2_DRIVER_TYPE A4988
//#define Z2_DRIVER_TYPE A4988
//#define Z3_DRIVER_TYPE A4988
//#define Z4_DRIVER_TYPE A4988
//#define E0_DRIVER_TYPE A4988
//#define E1_DRIVER_TYPE A4988
//#define E2_DRIVER_TYPE A4988
//#define E3_DRIVER_TYPE A4988
//#define E4_DRIVER_TYPE A4988
//#define E5_DRIVER_TYPE A4988
//#define E6_DRIVER_TYPE A4988
//#define E7_DRIVER_TYPE A4988

// Engedélyezze ezt a funkciót, ha az összes engedélyezett endstop pin megszakításra képes.
// Ezzel megszűnik a megszakító pinek lekérdezése, sok CPU-ciklust megtakarítva.
//#define ENDSTOP_INTERRUPTS_FEATURE

/**
 * Endstop-zajküszöb
 *
 * Engedélyezze, ha a szondája vagy a végén zaj miatt tévesen indul.
 *
 * - A magasabb értékek befolyásolhatják egyes ágyszonda megismételhetőségét vagy pontosságát.
 * - A zaj kijavításához telepítsen egy 100nF kerámia kondenzátort a kapcsolóval.
 * - Ez a szolgáltatás nem szükséges a NYÁK-ra szerelt általános mikrokapcsolókhoz
 * a Makerbot tervezésén alapul, amelyek már rendelkeznek a 100nF kondenzátorral.
 *
 * :[2,3,4,5,6,7]
 */
//#define ENDSTOP_NOISE_THRESHOLD 2

//=============================================================================
//============================== Mozgásbeállítások ============================
//=============================================================================
// @section mozgás

/**
 * Alapbeállítások
 *
 * Ezeket a beállításokat az M502 visszaállíthatja
 *
 * Vegye figyelembe, hogy ha az EEPROM engedélyezve van, a mentett értékek felülbírálják ezeket.
 */

/**
 * Ezzel az opcióval minden E léptetőnek megvannak a saját tényezői a
 * a mozgásbeállítások követésekor. Ha kevesebb tényezőt adnak meg, mint a
 * az extruderek teljes száma, az utolsó érték a többire vonatkozik.
 */
//#define DISTINCT_E_FACTORS

/**
* Alapértelmezett tengelylépések egységenként (lépések / mm)
 * Az M92 felülírja
 *                                      X, Y, Z, E0 [, E1[, E2...]]
 */
#define DEFAULT_AXIS_STEPS_PER_UNIT   { 80, 80, 4000, 500 }

/**
 * Alapértelmezett maximális előtolási sebesség (mm / s)
 * Az M203 felülírja
 *                                      X, Y, Z, E0 [, E1[, E2...]]
 */
#define DEFAULT_MAX_FEEDRATE          { 300, 300, 5, 25 }

//#define LIMITED_MAX_FR_EDITING        // A szerkesztést az M203 vagy az LCD segítségével korlátozza a DEFAULT_MAX_FEEDRATE * 2 értékre.
#if ENABLED(LIMITED_MAX_FR_EDITING)
  #define MAX_FEEDRATE_EDIT_VALUES    { 600, 600, 10, 50 } // ... vagy állítsa be saját szerkesztési korlátait
#endif

/**
 * Alapértelmezett maximális gyorsulás (változás / s) változás = mm / s
 * (Maximális indulási sebesség gyorsított mozgásoknál)
 * Az M201 felülírja
 *                                      X, Y, Z, E0 [, E1[, E2...]]
 */
#define DEFAULT_MAX_ACCELERATION      { 3000, 3000, 100, 10000 }

//#define LIMITED_MAX_ACCEL_EDITING     // A szerkesztést az M201 vagy az LCD segítségével korlátozza a DEFAULT_MAX_ACCELERATION * 2 értékre.
#if ENABLED(LIMITED_MAX_ACCEL_EDITING)
  #define MAX_ACCEL_EDIT_VALUES       { 6000, 6000, 200, 20000 } // ... vagy állítsa be saját szerkesztési korlátait
#endif

/**
 * Alapértelmezett gyorsulás (változás / s) változás = mm / s
 * Az M204 felülírása
 *
 * M204 	P gyorsulás
 * M204 	R visszahúzási gyorsítás
 * M204 	T menetgyorsulás
 */
#define DEFAULT_ACCELERATION          3000    // X, Y, Z és E gyorsítás a nyomtatási lépésekhez
#define DEFAULT_RETRACT_ACCELERATION  3000    // Az E gyorsítás a visszahúzódásokhoz
#define DEFAULT_TRAVEL_ACCELERATION   3000    // X, Y, Z gyorsítás utazási (nem nyomtatás) mozgásokhoz

/**
* Alapértelmezett Jerk határok (mm / s)
 * fellülírás az M205 X Y Z E-vel
 *
 * A "Jerk" megadja a gyorsulást igénylő minimális sebességváltozást.
 * A sebesség és az irány megváltoztatásakor, ha a különbség kisebb, mint a
 * itt beállított érték, akkor azonnal megtörténhet.
 */
//#define CLASSIC_JERK
#if ENABLED(CLASSIC_JERK)
  #define DEFAULT_XJERK 10.0
  #define DEFAULT_YJERK 10.0
  #define DEFAULT_ZJERK  0.3

  //#define TRAVEL_EXTRA_XYJERK 0.0     // Kiegészítő rátás pótlék minden utazáshoz

  //#define LIMITED_JERK_EDITING        // A szerkesztést az M205 vagy az LCD segítségével korlátozza a DEFAULT_aJERK * 2 értékre.
  #if ENABLED(LIMITED_JERK_EDITING)
    #define MAX_JERK_EDIT_VALUES { 20, 20, 0.6, 10 } // ... vagy állítsa be saját szerkesztési korlátait
  #endif
#endif

#define DEFAULT_EJERK    5.0  // A Lineáris haladás felhasználhatja

/**
 * Junction Deviation Factor
 *
 * See:
 *   https://reprap.org/forum/read.php?1,739819
 *   http://blog.kyneticcnc.com/2018/10/computing-junction-deviation-for-marlin.html
 */
#if DISABLED(CLASSIC_JERK)
  #define JUNCTION_DEVIATION_MM 0.013 // (mm) Távolság a tényleges csomópont szélétől
#endif

/**
 * S-görbe gyorsítás
 *
 * Ez az opció a Bézier illesztésével kiküszöböli a rezgést a nyomtatás során
 * görbe a gyorsulás mozgatásához, sokkal simább irányváltásokat eredményezve.
 *
 * Lásd: https://github.com/synthetos/TinyG/wiki/Jerk-Controlled-Motion-Explained
 */
//#define S_CURVE_ACCELERATION

//===========================================================================
//============================= Z szonda opciók =============================
//===========================================================================
// @section szondák

//
// See http://marlinfw.org/docs/configuration/probes.html
//

/**
 * Z_MIN_PROBE_USES_Z_MIN_ENDSTOP_PIN
 *
 * Engedélyezze ezt az opciót a Z Min végállványhoz csatlakoztatott szonda számára.
 */
#define Z_MIN_PROBE_USES_Z_MIN_ENDSTOP_PIN

/**
 * Z_MIN_PROBE_PIN
 *
 * Adja meg ezt a tűt, ha a szonda nincs csatlakoztatva a Z_MIN_PIN-hez.
 * Ha nincs megadva az alapértelmezett PIN-kód a kiválasztott MOTORTábla számára
 * használva lesz. Az alapértelmezés általában a kívánt.
 *
 *  - A legegyszerűbb lehetőség egy szabad endstop csatlakozó használata.
 *  - Használjon 5 V-os tápfeszültségű (általában induktív) érzékelőket.
 *
 *  - A RAMPS 1.3 / 1.4 táblák használhatják az 5 V, GND és Aux4-> D32 tűt:
 *    - Az egyszerű kapcsolókhoz csatlakoztassa ...
 *      - normally-closed (normál-zárt) kapcsoló GND és D32.
 *      - normally-open (normlá-nyitva) kapcsol 5V és D32 feszültségre.
 *
 */
//#define Z_MIN_PROBE_PIN 32 // Pin 32 is the RAMPS default

/**
 * Szonda típusa
 *
 * Imbuszkulcs szonda, szervó szonda, Z-Sled szonda, FIX_MOUNTED_PROBE stb.
 * Aktiválja az egyiket az alábbi automatikus ágyszintezés használatához.
 */

/**
 * A „Kézi szonda” lehetőséget nyújt az „Automatikus” ágyszintezésre szonda nélkül.
 * Használja ismételten a G29-et, állítva a Z magasságát minden egyes ponton a mozgási parancsokkal
 * vagy (LCD_BED_LEVELING esetén) az LCD-vezérlő.
 */
//#define PROBE_MANUALLY
//#define MANUAL_PROBE_START_Z 0.2

/**
 * A rögzített szonda vagy nem települ, vagy kézi telepítésre van szüksége.
 * (például egy induktív szonda vagy egy fúvóka alapú szonda kapcsoló).
 */
//#define FIX_MOUNTED_PROBE

/**
 * A fúvókát szondaként használja, mint a vezetőkével
 * fúvókarendszer vagy piezoelektromos intelligens effektor.
 */
//#define NOZZLE_AS_PROBE

/**
 * Z Servo Probe, például egy forgókar végálláskapcsolója.
 */
//#define Z_PROBE_SERVO_NR 0       // Alapértelmezés szerint a SERVO 0 csatlakozó.
//#define Z_SERVO_ANGLES { 70, 0 } // Z Szervo telepítés és tárolás szöge

/**
 * A BLTouch szonda Hall effekt érzékelőt használ és szervót emulál.
 */
//#define BLTOUCH

/**
 * Touch-MI szonda a hotends.fr oldalon
 *
 * Ezt a szondát úgy kell telepíteni és aktiválni, hogy az X tengelyt az ágy szélén lévő mágnesre mozgatja.
 * Alapértelmezés szerint a mágnest feltételezik, hogy bal oldalon van, és egy home aktiválja. Ha a mágnes
 * a jobb oldalon engedélyezze és állítsa a TOUCH_MI_DEPLOY_XPOS telepítési helyzetbe.
 *
 * Szükséges továbbá: BABYSTEPPING, BABYSTEP_ZPROBE_OFFSET, Z_SAFE_HOMING,
 *                és legalább 10 Z_HOMING_HEIGHT.
 */
//#define TOUCH_MI_PROBE
#if ENABLED(TOUCH_MI_PROBE)
  #define TOUCH_MI_RETRACT_Z 0.5                  // A szonda visszahúzási magassága
  //#define TOUCH_MI_DEPLOY_XPOS (X_MAX_BED + 2)  // Mágneshez az ágy jobb oldalán
  //#define TOUCH_MI_MANUAL_DEPLOY                // Kézi üzembe helyezéshez (LCD menü)
#endif

// Szonda, amelyet egy mágnesszeleppel (SOL1_PIN) telepítettek és helyeztek el
//#define SOLENOID_PROBE

// A szánra szerelt szonda, mint például Charles Bell.
//#define Z_PROBE_SLED
//#define SLED_DOCKING_OFFSET 5  / Az X tengely extra távolságának meg kell haladnia a szán felvételéhez. 
//A 0-nak jól kell lennie, de tovább tudja tolni, ha szeretné.
//  Szonda, amelyet az x tengely mozgatásával telepítettek, mint például a Wilson II állvány- és fogaskerék-szonda, amelyet Marty Rice tervezett.
//#define RACK_AND_PINION_PROBE
#if ENABLED(RACK_AND_PINION_PROBE)
  #define Z_PROBE_DEPLOY_X  X_MIN_POS
  #define Z_PROBE_RETRACT_X X_MAX_POS
#endif

// Duet Smart Effector (delta nyomtatókhoz) - https://bit.ly/2ul5U7J
// Amikor a pin meg van határozva, az M672 segítségével beállíthatja / visszaállíthatja a szonda érzékenységét.
//#define DUET_SMART_EFFECTOR
#if ENABLED(DUET_SMART_EFFECTOR)
  #define SMART_EFFECTOR_MOD_PIN  -1  // Csatlakoztasson egy GPIO tűt a Smart Effector MOD tűjéhez
#endif

/**
 * A StallGuard2 segítségével vizsgálja meg az ágyat a fúvókával.
 * Szükséges a stallGuard kompatibilis Trinamic stepper meghajtók.
 * VIGYÁZAT: Ez károkat okozhat a Z vezetékcsavarokkal.
 *           A szolgáltatás beállításakor különös figyelmet kell fordítani.
 */
//#define SENSORLESS_PROBING

//
// A Z_PROBE_ALLEN_KEY esetén lásd a Delta példakonfigurációkat.
//

/**
 * Z A szonda és a fúvóka (X, Y) eltolása (0, 0) viszonylatban.
 *
 * A következő példában az X és Y eltolások egyaránt pozitívak:
 *
 *   #define NOZZLE_TO_PROBE_OFFSET { 10, 10, 0 }
 *
 *     +-- BACK ---+
 *     |           |
 *   L |    (+) P  | R <-- szonda (20,20)
 *   E |           | I
 *   F | (-) N (+) | G <-- nozzle (10,10)
 *   T |           | H
 *     |    (-)    | T
 *     |           |
 *     O-- FRONT --+
 *   (0,0)
 *
 * Adja meg a szonda helyzetét { X, Y, Z }
 */
#define NOZZLE_TO_PROBE_OFFSET { 10, 10, 0 }

// A legtöbb szondának az ágy széleitől távol kell maradnia, de
// a NOZZLE_AS_PROBE esetén ez negatív lehet egy szélesebb próbaterületnél.
#define MIN_PROBE_EDGE 10

//X és Y tengely haladási sebessége (mm / m) a szonda között
#define XY_PROBE_SPEED 8000

// Előtolás (mm / m) az első megközelítéshez dupla tapintással (MULTIPLE_PROBING == 2)
#define Z_PROBE_SPEED_FAST HOMING_FEEDRATE_Z

// Előtolás (mm / m) az egyes pontok "pontos" szondájához
#define Z_PROBE_SPEED_SLOW (Z_PROBE_SPEED_FAST / 2)

/**
 * Többszörös szondázás
 *
 * Jobb eredményeket érhet el, ha kétszer vagy többször próbálkozik.
 * Az EXTRA_PROBING használatával az atipikusabb olvasmányokat nem veszik figyelembe.
 *
 * Összesen 2 gyors / lassú szondát végez súlyozott átlaggal.
 * Összesen 3 vagy annál több lassabb szondát ad hozzá, az átlagot figyelembe véve.
 */
//#define MULTIPLE_PROBING 2
//#define EXTRA_PROBING    1

/**
 * A Z szondáknak kiürítésre van szükségük a kirakodás, a tárolás és az közötti mozgás során
 * szonda pontok, hogy elkerülje az ágy és más hardverek ütését.
 * A szervóra szerelt érzékelőknek további hely szükséges a kar forgásához.
 * Az induktív szondáknak helyet kell igénybe venniük, hogy ne induljanak korán.
 *
 * Ezekkel a beállításokkal határozhatja meg a tapintó távolságát (mm) (vagy
 * engedje le az ágyat). Az itt megadott értékek minden (negatív) fölött érvényesek
 * Z szonda eltolás beállítva NOZZLE_TO_PROBE_OFFSET, M851 vagy az LCD-vel.
 * Csak az egész = = 1 érték érvényes itt.
 *
 * Példa: `M851 Z-5`, SZÖVEGSÉG 4 => 9 mm az ágytól a fúvókáig.
 * De: `M851 Z + 1`, SZÖVEGSÉG 2 => 2 mm az ágytól a fúvókáig.
 */
#define Z_CLEARANCE_DEPLOY_PROBE   10 // Z Telepítési / tárolási engedély
#define Z_CLEARANCE_BETWEEN_PROBES  5 // Z távolság a szondapontok között
#define Z_CLEARANCE_MULTI_PROBE     5 // Z Több szonda közötti hézag
//#define Z_AFTER_PROBING           5 // Z pozíciót a szondázás után

#define Z_PROBE_LOW_POINT          -2 // A trigger-pont alatt lévő legtávolabbi távolság megállás előtt

// Az M851 esetében adjon meg egy tartományt a Z szonda eltolásának beállításához
#define Z_PROBE_OFFSET_RANGE_MIN -20
#define Z_PROBE_OFFSET_RANGE_MAX 20

// Engedélyezze az M48 ismételhetőségi tesztet a szonda pontosságának teszteléséhez
//#define Z_MIN_PROBE_REPEATABILITY_TEST

// Mielőtt telepíteni / szünetet tartana a felhasználói megerősítéshez
//#define PAUSE_BEFORE_DEPLOY_STOW
#if ENABLED(PAUSE_BEFORE_DEPLOY_STOW)
  //#define PAUSE_PROBE_DEPLOY_WHEN_TRIGGERED // Allenkey Probe kézi üzembe helyezéséhez
#endif

/**
 * Engedélyezze az alábbiak közül egyet vagy többet, ha a vizsgálás megbízhatatlannak tűnik.
 * A fűtőberendezéseket és / vagy a ventilátorokat le lehet tiltani szondázás közben az elektromos zaj minimalizálása érdekében.
 * Késleltetés is hozzáadható, hogy a zaj és a vibráció leülepedhessen.
 * Ezek a lehetőségek a leghatékonyabbak a BLTouch szonda számára, de javulhatnak is
 * leolvasások induktív szondákkal és piezo szenzorokkal.
 */
//#define PROBING_HEATERS_OFF       // szondázáskor kapcsolja ki a fűtőberendezéseket
#if ENABLED(PROBING_HEATERS_OFF)
  //#define WAIT_FOR_BED_HEATER     // Várjon, amíg az ágy melegszik a szonda között (a pontosság javítása érdekében)
#endif
//#define PROBING_FANS_OFF          // Szondázáskor kapcsolja ki a ventilátort
//#define PROBING_STEPPERS_OFF      // Szondázás közben kapcsolja ki a lépcsőket (hacsak nem szükséges a helyzet tartásához)
//#define DELAY_BEFORE_PROBING 200  // (ms) A rezgések megakadályozása érdekében, hogy piezo szenzorok kiválthassanak

// A Stepper engedélyező csapok megfordításához (aktív alacsony) 0, nem invertáló (aktív magas) használatra 1
// :{ 0:'Low', 1:'High' }
#define X_ENABLE_ON 0
#define Y_ENABLE_ON 0
#define Z_ENABLE_ON 0
#define E_ENABLE_ON 0 // Minden extruder számára

// Azonnal letiltja a tengelylépcsőt, ha nem használja.
// FIGYELMEZTETÉS: A motorok kikapcsolása esetén elveszítheti a helyzet pontosságát!
#define DISABLE_X false
#define DISABLE_Y false
#define DISABLE_Z false

// Figyelmeztetés a képernyőn az esetlegesen csökkent pontosság miatt
//#define DISABLE_REDUCED_ACCURACY_WARNING

// @section extruder

#define DISABLE_E false             // For all extruders
#define DISABLE_INACTIVE_EXTRUDER   // Keep only the active extruder enabled

// @section machine

// Fordítsa meg a lépcső irányát. Cserélje ki (vagy fordítsa meg a motor csatlakozóját), ha egy tengely rosszul halad.
#define INVERT_X_DIR false
#define INVERT_Y_DIR true
#define INVERT_Z_DIR false

// @section extruder

// A v9 közvetlen hajtású extruder esetében true értékre van állítva, a hajtómű extruder esetén false értékre.
#define INVERT_E0_DIR false
#define INVERT_E1_DIR false
#define INVERT_E2_DIR false
#define INVERT_E3_DIR false
#define INVERT_E4_DIR false
#define INVERT_E5_DIR false
#define INVERT_E6_DIR false
#define INVERT_E7_DIR false

// @section homing

//#define NO_MOTION_BEFORE_HOMING // A mozgást gátolja mindaddig, amíg az összes tengely nem illeszkedik

//#define UNKNOWN_Z_NO_RAISE      // Ne emelje fel Z-t (engedje le az ágyat), ha Z "ismeretlen". Olyan ágyakhoz, amelyek esnek, amikor Z kikapcsol.

//#define Z_HOMING_HEIGHT  4      // (mm) minimális Z magasságot a behelyezés előtt (G28) az ágy fölötti Z távolságra, bilincsek, ...
                                  // Győződjön meg róla, hogy ilyen sok szabad hely van a Z_MAX_POS alatt, hogy megakadályozza az őrlést.

//#define Z_AFTER_HOMING  10      // (mm) A Z elhelyezés utáni magasság

// Direction of endstops when homing; 1=MAX, -1=MIN
// :[-1,1]
#define X_HOME_DIR -1
#define Y_HOME_DIR -1
#define Z_HOME_DIR -1

// @section machine

// A nyomtatóágy mérete
#define X_BED_SIZE 200
#define Y_BED_SIZE 200

// Haladási határértékek (mm) a behelyezés után, a végállási helyeknek megfelelően.
#define X_MIN_POS 0
#define Y_MIN_POS 0
#define Z_MIN_POS 0
#define X_MAX_POS X_BED_SIZE
#define Y_MAX_POS Y_BED_SIZE
#define Z_MAX_POS 200

/**
 * Szoftver Endstops
 *
 * - A mozgás megakadályozása a beállított gépi határokon kívül.
 * - Az egyes tengelyeket szükség esetén letilthatjuk.
 * - X és Y csak a derékszögű robotokra vonatkoznak.
 * - Az 'M211' gombbal állíthatja be a szoftver végállásait, illetve jelentheti az aktuális állapotot
 */

// A minimális szoftver megállítja a korlátozott mozgást a minimális koordináta-határokon belül
#define MIN_SOFTWARE_ENDSTOPS
#if ENABLED(MIN_SOFTWARE_ENDSTOPS)
  #define MIN_SOFTWARE_ENDSTOP_X
  #define MIN_SOFTWARE_ENDSTOP_Y
  #define MIN_SOFTWARE_ENDSTOP_Z
#endif

// A Max szoftver betartja a korlátozott mozgást a maximális koordináta-határokon belül
#define MAX_SOFTWARE_ENDSTOPS
#if ENABLED(MAX_SOFTWARE_ENDSTOPS)
  #define MAX_SOFTWARE_ENDSTOP_X
  #define MAX_SOFTWARE_ENDSTOP_Y
  #define MAX_SOFTWARE_ENDSTOP_Z
#endif

#if EITHER(MIN_SOFTWARE_ENDSTOPS, MAX_SOFTWARE_ENDSTOPS)
  //#define SOFT_ENDSTOPS_MENU_ITEM  // A szoftver végállomásainak engedélyezése / letiltása az LCD-n
#endif

/**
 * Filament kifutási érzékelők
 * Mechanikus vagy opto végállomásokat használnak az izzószál jelenlétének ellenőrzésére.
 *
 * A RAMPS-alapú táblák a SERVO3_PIN-t használják az első runout-érzékelőhöz.
 * Más táblák esetében meg kell határoznia a FIL_RUNOUT_PIN, FIL_RUNOUT2_PIN stb.
 * Alapértelmezés szerint a firmware feltételezi, hogy HIGH = FILAMENT PRESENT.
 */
//#define FILAMENT_RUNOUT_SENSOR
#if ENABLED(FILAMENT_RUNOUT_SENSOR)
  #define NUM_RUNOUT_SENSORS   1     // Érzékelők száma, extruderenként legfeljebb egy. Adjon meg mindegyiknek egy FIL_RUNOUT # _PIN-t.
  #define FIL_RUNOUT_INVERTING false // Állítsa be true értékre, hogy megfordítsa az érzékelő logikáját.
  #define FIL_RUNOUT_PULLUP          // Használjon belső pullup az filament pinekhez.
  //#define FIL_RUNOUT_PULLDOWN      // Használjon belső pulldown elemet az filament kifutási pinjeihez.

  // Állítson be egy vagy több parancsot az filament futtatására.
  // (Az 'M412 H' után Marlin felkéri a gazdagépet, hogy kezelje a folyamatot.)
  #define FILAMENT_RUNOUT_SCRIPT "M600"

  // Miután kimutatták a kifogyást, folytassa az filament ilyen hosszúságát
  // a runout parancs végrehajtása előtt. Hasznos egy érzékelőnél a végén
  // egy adagolócső. Szenzoronként 4 bájt SRAM szükséges, plusz 4 bájt fölött.
  //#define FILAMENT_RUNOUT_DISTANCE_MM 25

  #ifdef FILAMENT_RUNOUT_DISTANCE_MM
    // Engedélyezze ezt az opciót, ha olyan kódoló lemezt használ, amely átváltja a kifutó pint
    // az izzószál mozgása közben. (Ügyeljen arra, hogy állítsa be a FILAMENT_RUNOUT_DISTANCE_MM beállítást
    // elég nagy ahhoz, hogy elkerülje a hamis pozitív eredményeket.)
	
	
    //#define FILAMENT_MOTION_SENSOR
  #endif
#endif

//===========================================================================
//=============================== Ágyszintezés ==============================
//===========================================================================
// @section calibrate

/**
 * Válassza az alábbi lehetőségek egyikét a G29 ágyszintezés engedélyezéséhez. A paraméterek
 * és a G29 viselkedése a választástól függően változni fog.
 *
 * Ha a Z Hominghoz érzékelőt használ, engedélyezze a Z_SAFE_HOMING funkciót is!
 *
 * - AUTO_BED_LEVELING_3POINT
 * Próba 3 tetszőleges pontot az ágyon (amelyek nem egyenesek)
 * Meghatározza mindhárom pont XY koordinátáit.
 * Az eredmény egy döntött sík. A legjobb egy lapos ágyhoz.
 *
 * - AUTO_BED_LEVELING_LINEAR
 * Vizsgáljon meg több pontot a rácsban.
 * Megadja a téglalapot és a mintapontok sűrűségét.
 * Az eredmény egy döntött sík. A legjobb egy lapos ágyhoz.
 *
 * - AUTO_BED_LEVELING_BILINEAR
 * Vizsgáljon meg több pontot a rácsban.
 * Megadja a téglalapot és a mintapontok sűrűségét.
 * Az eredmény háló, a legjobb nagy vagy egyenetlen ágyakhoz.
 *
 * - AUTO_BED_LEVELING_UBL (Unified Bed Leveling)
 * Átfogó ágyszintező rendszer, amely egyesíti a funkciókat és az előnyöket
 * más rendszerek. Az UBL magában foglalja az integrált Mesh Generation-et is
 * Érvényesítési és hálószerkesztő rendszereket.
 *
 * - MESH_BED_LEVELING
 * Vizsgálja meg a rácsot kézzel
 * Az eredmény egy háló, nagy vagy egyenetlen ágyakhoz alkalmas. (Lásd a BILINEAR-t.)
 * Szonda nélküli gépeknél a hálóágy-szintezés eljárást biztosít
 * szintezés lépésekben, így manuálisan beállíthatja a Z magasságot minden rácspontnál.
 * LCD-vezérlővel a folyamat lépésről lépésre történik.
 */
//#define AUTO_BED_LEVELING_3POINT
//#define AUTO_BED_LEVELING_LINEAR
//#define AUTO_BED_LEVELING_BILINEAR
//#define AUTO_BED_LEVELING_UBL
//#define MESH_BED_LEVELING

/**
 * A G28 rendszerint kikapcsolja a vízszintezést befejezéskor. Engedélyezze
 * ezt az opciót, ha a G28 visszaállítja az előző szintezési állapotot.
 */
//#define RESTORE_LEVELING_AFTER_G28

/**
 * A G28, G29, M48 stb. Részletes naplózásának engedélyezése
 * Kapcsolja be az 'M111 S32' paranccsal.
 * MEGJEGYZÉS: Nagyon sok PROGMEM szükséges!
 */
//#define DEBUG_LEVELING_FEATURE

#if ANY(MESH_BED_LEVELING, AUTO_BED_LEVELING_BILINEAR, AUTO_BED_LEVELING_UBL)
  // Fokozatosan csökkentse a szintezési korrekciót, amíg el nem éri a beállított magasság,
  // azt a pontot, ahol a mozgás a gép XY síkjával megegyezik.
  // A magasság az M420 Z <magasság> segítségével állítható be
  #define ENABLE_LEVELING_FADE_HEIGHT

  // Derékszögű gépeknél a hálóhatáron történő mozdulatok elosztása helyett
  // a felosztás rövid szakaszokra mozog, mint egy Delta. Ez követi
  // az ágy körvonalait szorosabban, mint a szélek-szélek közötti egyenes mozdulatai.
  #define SEGMENT_LEVELED_MOVES
  #define LEVELED_SEGMENT_LENGTH 5.0 // // (mm) Az összes szegmens hossza (az utolsó kivételével)

  /**
   Engedélyezze a G26 hálóvalidációs mintázat eszközét.
   */
  //#define G26_MESH_VALIDATION
  #if ENABLED(G26_MESH_VALIDATION)
    #define MESH_TEST_NOZZLE_SIZE    0.4  // (mm) Az elsődleges fúvóka átmérője.
    #define MESH_TEST_LAYER_HEIGHT   0.2  // (mm) Az alapértelmezett rétegmagasság a G26 háló-ellenőrző eszköz számára.
    #define MESH_TEST_HOTEND_TEMP  205    // (°C) A fúvóka alapértelmezett hőmérséklete a G26 háló-ellenőrző eszköznél.
    #define MESH_TEST_BED_TEMP      60    // (°C) Az alapértelmezett ágyhőmérséklet a G26 háló-ellenőrző eszközhöz.
    #define G26_XY_FEEDRATE         20    // (mm/s) betáplálási sebesség az XY mozgatásokhoz a G26 háló-ellenőrző eszközhez.
    #define G26_RETRACT_MULTIPLIER   1.0  // G26 Q (visszahúzás), amelyet alapértelmezés szerint használt a hálóteszt elemek között.
  #endif

#endif

#if EITHER(AUTO_BED_LEVELING_LINEAR, AUTO_BED_LEVELING_BILINEAR)

  // Állítsa be a rácspontok számát dimenziónként.
  #define GRID_MAX_POINTS_X 3
  #define GRID_MAX_POINTS_Y GRID_MAX_POINTS_X

  // Szonda az Y tengely mentén, az X előrehaladásával minden oszlop után
  //#define PROBE_Y_FIRST

  #if ENABLED(AUTO_BED_LEVELING_BILINEAR)

    // Folytassa a vizsgált rácson túl az implikált döntést?
    // Alapértelmezés szerint a legközelebbi él magasságát kell fenntartani.
    //#define EXTRAPOLATE_BEYOND_GRID

    //
    // A rács kísérleti felosztása Catmull-Rom módszerrel.
    // A köztes pontokat szintetizálja, hogy részletesebb hálót kapjon.
    //
    //#define ABL_BILINEAR_SUBDIVISION
    #if ENABLED(ABL_BILINEAR_SUBDIVISION)
      // A szondapontok közötti felosztás száma
      #define BILINEAR_SUBDIVISIONS 3
    #endif

  #endif

#elif ENABLED(AUTO_BED_LEVELING_UBL)

  //===========================================================================
  //========================= Egységes ágyszintezés ===========================
  //===========================================================================

  //#define MESH_EDIT_GFX_OVERLAY   // Grafikai overlay megjelenítése a háló szerkesztése közben

  #define MESH_INSET 1              // Állítsa be a hálószögeket az ágy beágyazott részének
  #define GRID_MAX_POINTS_X 10      // Ne használjon tengelyenként több, mint 15 pontot, a végrehajtás korlátozott.
  #define GRID_MAX_POINTS_Y GRID_MAX_POINTS_X

  #define UBL_MESH_EDIT_MOVES_Z     // A kifinomult felhasználók inkább nem mozgatják a fúvókát
  #define UBL_SAVE_ACTIVE_ON_M500   // Mentse el az aktuálisan aktív hálót az M500 jelenlegi nyílásába

  //#define UBL_Z_RAISE_WHEN_OFF_MESH 2.5 // Amikor a fúvóka nincs a hálóban, ezt az értéket kell használni
                                          // mint Z-Magasság korrekciós érték.

#elif ENABLED(MESH_BED_LEVELING)

  //===========================================================================
  //=================================== Mesh ==================================
  //===========================================================================

  #define MESH_INSET 10          // Állítsa be a hálószögeket az ágy beágyazott részének
  #define GRID_MAX_POINTS_X 3    // Ne használjon tengelyenként több, mint 7 pontot, a végrehajtás korlátozott.
  #define GRID_MAX_POINTS_Y GRID_MAX_POINTS_X

  //#define MESH_G28_REST_ORIGIN // Az összes tengely ('G28' vagy 'G28 XYZ') beillesztése után nyugodjunk Z-n a Z_MIN_POS-n

#endif // BED_LEVELING

/**
 * Adjon hozzá egy ágyszintező almenüt az ABL vagy MBL számára.
 * Vegyen részt egy irányított eljárást, ha a kézi szondázás engedélyezve van.
 */
//#define LCD_BED_LEVELING

#if ENABLED(LCD_BED_LEVELING)
  #define MESH_EDIT_Z_STEP  0.025 // (mm) Lépésméret, miközben manuálisan vizsgálja a Z tengelyt.
  #define LCD_PROBE_Z_RANGE 4     // (mm) Z Z-tartomány középpontjában a Z_MIN_POS az LCD Z beállításához
  //#define MESH_EDIT_MENU        // Menü hozzáadása a hálópontok szerkesztéséhez
#endif

// Add a menu item to move between bed corners for manual bed adjustment
//#define LEVEL_BED_CORNERS

#if ENABLED(LEVEL_BED_CORNERS)
  #define LEVEL_CORNERS_INSET_LFRB { 30, 30, 30, 30 } // (mm) bal, elülső, jobb, hátsó betétek
  #define LEVEL_CORNERS_HEIGHT      0.0   // (mm) Z fúvóka magassága az egyengetési pontokon
  #define LEVEL_CORNERS_Z_HOP       4.0   // (mm) Z fúvóka magassága a kiegyenlítési pontok között
  //#define LEVEL_CENTER_TOO              // Mozog a központba az utolsó sarok után
#endif

/**
 * A G29 szondázás végén végrehajtandó parancsok.
 * Hasznos, hogy visszahúzza vagy mozgatja a Z szondát az útból.
 */
//#define Z_PROBE_END_SCRIPT "G1 Z10 F12000\nG1 X15 Y330\nG1 Z0.5\nG1 Z10"


// @section homing

// Az ágy középpontja (X = 0, Y = 0)
//#define BED_CENTER_AT_0_0

// Az home helyzet manuális beállítása. Hagyja ezeket meghatározatlanul az automatikus beállításoknál.
// A DELTA esetében ez a derékszögű nyomtatási kötet legfontosabb középpontja.
//#define MANUAL_X_HOME_POS 0
//#define MANUAL_Y_HOME_POS 0
//#define MANUAL_Z_HOME_POS 0

// Használja a "Z Safe Homing" funkciót, hogy elkerülje a Z szondával való ágyazást az ágy területén.
//
// Engedélyezve ezt a funkciót:
//
// - Engedélyezze a Z homingot csak az X és Y homing AND stepper illesztőprogramok engedélyezése után.
// - Ha a stepper sofőrök időtúllépnek, akkor ismét X és Y lesz szükség a homozingra.
// - Helyezze a Z szondát (vagy fúvókát) egy meghatározott XY pontra a Z Homing előtt, amikor az összes tengelyt beillesztik (G28).
// - Megakadályozhatja a Z elhelyezését, amikor a Z szonda az ágy területén kívül található.
//
//#define Z_SAFE_HOMING

#if ENABLED(Z_SAFE_HOMING)
  #define Z_SAFE_HOMING_X_POINT ((X_BED_SIZE) / 2)    // Z-pont X pontja, amikor az összes tengelyt homeolják (G28).
  #define Z_SAFE_HOMING_Y_POINT ((Y_BED_SIZE) / 2)    // Z-pont Y-pontja, amikor az összes tengelyt homeolják (G28).
#endif

// Homing sebesség (mm/m)
#define HOMING_FEEDRATE_XY (50*60)
#define HOMING_FEEDRATE_Z  (4*60)

// Ellenőrizze, hogy a végállások kiváltásra kerülnek-e a home mozgatás során
#define VALIDATE_HOMING_ENDSTOPS

// @section calibrate

/**
 * Bed Skew Compensation
 *
 * Ez a szolgáltatás kijavítja az XYZ tengelyek eltérését.
 *
 * Tegye a következőket, hogy az ágy ferde legyen az XY síkban:
 * 1. Nyomtasson ki egy tesztteret (például: https://www.thingiverse.com/thing:2563185)
 * 2. Az XY_DIAG_AC esetén mérje meg az A – C átlót
 * 3. Az XY_DIAG_BD esetén mérje meg a B átlót D-ig
 * 4. Az XY_SIDE_AD esetén mérje meg az A szélét a D szélig
 *
 * Marlin automatikusan kiszámítja a ferde tényezőket ezekből a mérésekből.
 * A ferdítési tényezőket kiszámíthatjuk és manuálisan is beállíthatjuk:
 *
 *  - AB számítás    : SQRT(2*AC*AC+2*BD*BD-4*AD*AD)/2
 *  - XY_SKEW_FACTOR : TAN(PI/2-ACOS((AC*AC-AB*AB-AD*AD)/(2*AB*AD)))
 *
 * Ha szükséges, kövesse ugyanazt az eljárást XZ és YZ esetén.
 * Használja ezeket a rajzokat referenciaként:
 *
 *    Y                     Z                     Z
 *    ^     B-------C       ^     B-------C       ^     B-------C
 *    |    /       /        |    /       /        |    /       /
 *    |   /       /         |   /       /         |   /       /
 *    |  A-------D          |  A-------D          |  A-------D
 *    +-------------->X     +-------------->X     +-------------->Y
 *     XY_SKEW_FACTOR        XZ_SKEW_FACTOR        YZ_SKEW_FACTOR
 */
//#define SKEW_CORRECTION

#if ENABLED(SKEW_CORRECTION)
   // Írja ide az összes hosszmérést:
  #define XY_DIAG_AC 282.8427124746
  #define XY_DIAG_BD 282.8427124746
  #define XY_SIDE_AD 200

  // Vagy itt közvetlenül állíthatja be az alapértelmezett ferde tényezőket
  // a fenti mérések felülbírálására:
  #define XY_SKEW_FACTOR 0.0

  //#define SKEW_CORRECTION_FOR_Z
  #if ENABLED(SKEW_CORRECTION_FOR_Z)
    #define XZ_DIAG_AC 282.8427124746
    #define XZ_DIAG_BD 282.8427124746
    #define YZ_DIAG_AC 282.8427124746
    #define YZ_DIAG_BD 282.8427124746
    #define YZ_SIDE_AD 200
    #define XZ_SKEW_FACTOR 0.0
    #define YZ_SKEW_FACTOR 0.0
  #endif

  // Engedélyezze ezt az opciót az M852 számára, hogy futásidejűleg beállítsa a ferdést
  //#define SKEW_CORRECTION_GCODE
#endif

//=============================================================================
//============================= További funkciók ===========================
//=============================================================================

// @section extras

/**
 * EEPROM
 *
 * Állandó tárolás a konfigurálható beállítások megőrzése érdekében az újraindítás során.
 *
 *   M500 -  A beállításokat EEPROM-on tárolja.
 *   M501 -  Olvassa el a beállításokat az EEPROM-ból. (azaz mentse el a nem mentett változtatásokat)
 *   M502 -  A beállítások visszaállítása a gyári alapértékekre. (Kövesse az M500-tal az EEPROM indításához.)
 */
//#define EEPROM_SETTINGS     // Állandó tárolás az M500 és M501 eszközökkel
//#define DISABLE_M503        // ~ 2700 bájt ment a PROGMEM-be. Kapcsolja ki a release-hez.
#define EEPROM_CHITCHAT       // Visszajelzés küldése az EEPROM parancsokról. Letiltja a PROGMEM mentését.
#if ENABLED(EEPROM_SETTINGS)  
  //#define EEPROM_AUTO_INIT  // Az EEPROM automatikusan inicializál minden hibát.
#endif

//
// Host Keepalive
//
// Amikor engedélyezve van, Marlin foglalt állapotüzenetet küld a gazdagépnek
// pár másodpercenként, ha nem tudja parancsokat elfogadni.
//
#define HOST_KEEPALIVE_FEATURE        // Disable this if your host doesn't like keepalive messages
#define DEFAULT_KEEPALIVE_INTERVAL 2  // Number of seconds between "busy" messages. Set with M113.
#define BUSY_WHILE_HEATING            // Some hosts require "busy" messages even during heating

//
// G20 / G21 hüvelykes módú támogatás
//
//#define INCH_MODE_SUPPORT

//
// M149 Set temperature units support
//
//#define TEMPERATURE_UNITS_SUPPORT

// @section temperature

// Konstans előmelegítése
#define PREHEAT_1_LABEL       "PLA"
#define PREHEAT_1_TEMP_HOTEND 180
#define PREHEAT_1_TEMP_BED     70
#define PREHEAT_1_FAN_SPEED     0 // Érték 0 és 255 között

#define PREHEAT_2_LABEL       "ABS"
#define PREHEAT_2_TEMP_HOTEND 240
#define PREHEAT_2_TEMP_BED    110
#define PREHEAT_2_FAN_SPEED     0 // Érték 0 és 255 között

/**
 * Fúvóka park
 *
 * Parkolja a fúvókát az adott XYZ helyzetbe alapjáraton vagy G27-en.
 *
 * A "P" paraméter vezérli a Z tengelyre végrehajtott műveletet:
 *
 *    P0  (Default) Ha Z a Z alatt parkol, emelje fel a fúvókát.
 *    P1  A fúvókát mindig emelje fel Z-parkoló magasságba.
 *    P2  Emelje meg a fúvókát a Z-parkoló mennyiséggel, korlátozva a Z_MAX_POS-ra.
 */
//#define NOZZLE_PARK_FEATURE

#if ENABLED(NOZZLE_PARK_FEATURE)
  // Adjon meg egy parkhelyzetet: {X, Y, Z_raise}
  #define NOZZLE_PARK_POINT { (X_MIN_POS + 10), (Y_MAX_POS - 10), 20 }
  #define NOZZLE_PARK_XY_FEEDRATE 100   // (mm/s) X és Y tengely előtolása (a Z delta tengelyére is alkalmazva)
  #define NOZZLE_PARK_Z_FEEDRATE 5      // (mm/s) Z tengely előtolása (nem használt delta nyomtatókhoz)
#endif

/**
 * A fúvóka  tisztító funkció - Kísérleti
 *
 * A G12 parancsot hozzáfűzi a fúvókák tisztítási folyamatához.
 *
 * Paraméterek:
 *   P  minta
 *   S  stroke és ismétlések
 *   T  háromszögek (csak P1)
 *
 * Minta:
 *   P0  Egyenes (alapértelmezett). Ehhez szivacs típusú anyag szükséges
 *       rögzített ágyban. "S" határozza meg az ecsetvonásokat (azaz a hátra mozgásokat)
 *       a kezdő és a végpont között.
 *
 *   P1  Cik-cakk mintázat (X0, Y0) és (X1, Y1) között, "T" határozza meg a
 *       a cikcakk háromszögek száma. "S" határozza meg az ecsetvonások számát.
 *       A cikk-cakk elvégzése attól függ, hogy melyik a szűkebb.
 *       Például a "G12 P1 S1 T3" végrehajtja:
 *
 *          --
 *         |  (X0, Y1) |     /\        /\        /\     | (X1, Y1)
 *         |           |    /  \      /  \      /  \    |
 *       A |           |   /    \    /    \    /    \   |
 *         |           |  /      \  /      \  /      \  |
 *         |  (X0, Y0) | /        \/        \/        \ | (X1, Y0)
 *          --         +--------------------------------+
 *                       |________|_________|_________|
 *                           T1        T2        T3
 *
 *   P2  Kör alakú mintázat közepével a NOZZLE_CLEAN_CIRCLE_MIDDLE-nél.
 *       "R" a sugarat adja meg. "S" határozza meg a stroke számot.
 *       Indítás előtt a fúvóka a NOZZLE_CLEAN_START_POINT helyzetbe kerül.
 *
 *   Figyelmeztetések: A Z befejezésének meg kell egyeznie a Z kezdésével.
 * Figyelem: KÍSÉRLET. A G-kód argumentumai megváltozhatnak.
 *
 */
//#define NOZZLE_CLEAN_FEATURE

#if ENABLED(NOZZLE_CLEAN_FEATURE)
  // A minta ismétlések alapértelmezett száma
  #define NOZZLE_CLEAN_STROKES  12

  // Háromszögek alapértelmezett száma
  #define NOZZLE_CLEAN_TRIANGLES  3

  // Adja meg az egyes szerszámok pozícióit: { { X, Y, Z }, { X, Y, Z } }
  // A kettős hotend rendszer használhatja a { {  -20, (Y_BED_SIZE / 2), (Z_MIN_POS + 1) },  {  420, (Y_BED_SIZE / 2), (Z_MIN_POS + 1) }}
  #define NOZZLE_CLEAN_START_POINT { {  30, 30, (Z_MIN_POS + 1) } }
  #define NOZZLE_CLEAN_END_POINT   { { 100, 60, (Z_MIN_POS + 1) } }

  // Kör alakú sugara
  #define NOZZLE_CLEAN_CIRCLE_RADIUS 6.5
  // Kör alakú kör töredékek száma
  #define NOZZLE_CLEAN_CIRCLE_FN 10
  // A kör középpontja
  #define NOZZLE_CLEAN_CIRCLE_MIDDLE NOZZLE_CLEAN_START_POINT

  // Tisztítás után állítsa a fúvókát a kiindulási helyzetbe
  #define NOZZLE_CLEAN_GOBACK

  // Engedélyezze egy tisztító / tisztító állomást, amely mindig a portálmagasságban van (így nincs Z lépés)
  //#define NOZZLE_CLEAN_NO_Z
#endif

/**
 * Nyomtatási feladat időzítő
 *
 * Az M104/M109/M190 készüléken automatikusan elindítja és leállítja a nyomtatási feladat időzítőjét.
 *
 *   M104 (hotend, nincs várakozás) - magas hőmérséklet = nincs, 			alacsony hőmérséklet = stop időzítő
 *   M109 (forró, várjon) 			- magas hőmérséklet = indítási időzítő, alacsony hőmérséklet = stop időzítő
 *   M190 (ágy, várjon) 			- magas hőmérséklet = indítási időzítő, alacsony hőmérséklet = nincs
 *
  * Az időzítő az alábbi parancsokkal is vezérelhető:
 *
 *   M75 - A nyomtatási időzítő indítása
 *   M76 - A nyomtatási időzítő szüneteltetése
 *   M77 - A nyomtatási időzítő leállítása
 */
#define PRINTJOB_TIMER_AUTOSTART

/**
 * Nyomtatási számláló
 *
 * Statisztikai adatok nyomon követése, például:
 *
 *  - Összes nyomtatási feladat
 *  - Összes sikeres nyomtatási munka
 *  - Összes sikertelen nyomtatási munka
 *  - A teljes nyomtatás ideje
 *
 * Tekintse meg az aktuális statisztikákat az M78 segítségével.
 */
//#define PRINTCOUNTER

//=============================================================================
//============================= LCD és SD támogatás============================
//=============================================================================

// @section lcd

/**
 * LCD NYELV
 *
 * Válassza ki az LCD-n megjelenítendő nyelvet. Ezek a nyelvek állnak rendelkezésre:
 *
 * hu, egy, bg, ca, cz, da, de, el, el_gr, es, eu, fi, fr, gl, hr, it, jp_kana,
 * ko_KR, nl, pl, pt, pt_br, ru, sk, tr, uk, vi, zh_CN, zh_TW, teszt
 *
 * : {'en': 'angol', 'an': 'Aragonese', 'bg': 'bolgár', 'ca': 'katalán', 'cz': 'cseh', 'da': 'dán' , „de”: „német”, „el”: „görög”, „el_gr”: „görög (Görögország)”, „es”: „spanyol”, „eu”: „baszk-euskera”, „fi”: „Finn”, „fr”: „francia”, „gl”: „galíciai”, „hr”: „horvát”, „it”: „olasz”, „jp_kana”: „japán”, „ko_KR”: „koreai (Dél-Korea) ”,„ nl ”:„ holland ”,„ pl ”:„ lengyel ”,„ pt ”:„ portugál ”,„ pt_br ”:„ portugál (brazil) ”,„ ru ”:„ orosz ”,„ sk ”:„ szlovák ”,„ tr ”:„ török ​​”,„ uk ”:„ ukrán ”,„ vi ”:„ vietnami ”,„ zh_CN ”:„ kínai (egyszerűsített) ”,„ zh_TW ”:„ kínai (hagyományos) )', 'teszt' }
 * */
#define LCD_LANGUAGE en

/**
 * LCD karakterkészlet
 *
 * Megjegyzés: Ez az opció NEM vonatkozik a grafikus képernyőkre.
 *
 * Az összes karakter alapú LCD-k ASCII-t és ezek egyikét biztosítják
 * nyelvbővítmények:
 *
 * 	- JAPÁN ... 	a leggyakoribb
 * 	- WESTERN ... 	ékesebb karakterekkel
 * 	- CYRILLIC ... 	az orosz nyelvre
 *
 * A vezérlőre telepített nyelvkiterjesztés meghatározása:
 *
 * 	- Összeállítás és feltöltés az LCD_LANGUAGE 'teszt' beállításával
 * 	- Kattintson a vezérlőre az LCD menü megjelenítéséhez
 * 	- Az LCD-n japán, nyugati vagy cirill szöveg jelenik meg
 *
 * Lásd: http://marlinfw.org/docs/development/lcd_language.html
 *
 * :['JAPANESE', 'WESTERN', 'CYRILLIC']
 */
#define DISPLAY_CHARSET_HD44780 JAPANESE

/**
 * Információs képernyő stílus (0: klasszikus, 1: Prusa)
 *
 * : [0: 'klasszikus', 1: 'prusa']
 */
#define LCD_INFO_SCREEN_STYLE 0

/**
 * SD KÁRTYA
 *
 * Az SD kártya támogatása alapértelmezés szerint le van tiltva. Ha a vezérlő rendelkezik SD-nyílással,
 * törölnie kell a következő lehetőséget, különben nem fog működni.
 *
 */
//#define SDSUPPORT

/**
 * SD CARD: SPI SPEED
 *
 * Enable one of the following items for a slower SPI transfer speed.
 * This may be required to resolve "volume init" errors.
 */
//#define SPI_SPEED SPI_HALF_SPEED
//#define SPI_SPEED SPI_QUARTER_SPEED
//#define SPI_SPEED SPI_EIGHTH_SPEED

/**
 * SD KÁRTYA: CSATLAKOZTATVA
 *
 * Használjon CRC ellenőrzéseket és újrapróbálkozásokat az SD kommunikációban.
 */
//#define SD_CHECK_AND_RETRY

/**
 * LCD menü elemek
 *
 * Kapcsolja ki az összes menüt, és csak az Állapot képernyőt jelenítse meg, vagy
 * Csak távolítson el néhány idegen menüelemet a hely helyrehozása érdekében.
 */
//#define NO_LCD_MENUS
//#define SLIM_LCD_MENUS

//
// ENCODER BEÁLLÍTÁSOK
//
// Ez az opció felülbírálja a szükséges kódoló impulzusok alapértelmezett számát
// készítsen egy lépést. A nagy felbontású kódolóknál növelni kell.
//
//#define ENCODER_PULSES_PER_STEP 4

//
// Ezzel az opcióval felülírhatja a szükséges lépésjelek számát
// lépés a következő / előző menüelemek között.
//
//#define ENCODER_STEPS_PER_MENU_ITEM 1

/**
 * Encoder irányítási lehetőségek
 *
 * Először ellenőrizze a kódoló viselkedését mindkét lehetőség letiltásával.
 *
 * 	Fordított érték szerkesztés és Navigációs menü? A REVERSE_ENCODER_DIRECTION engedélyezése.
 * 	Csak fordított menünavigáció? 					A REVERSE_MENU_DIRECTION engedélyezése.
 * 	Csak fordított érték szerkesztés? 				Engedélyezze BOTH lehetőséget.
 */

//
// Ez az opció visszafordítja a Encoder irányát mindenütt.
//
// Ezt az opciót akkor állítsa be, ha a CLOCKWISE az értékeket CSÖKKENTI
//
//#define REVERSE_ENCODER_DIRECTION

//
// Ez az opció megfordítja a Encoder irányát az LCD menükben való navigáláshoz.
//
// 	Ha a CLOCKWISE általában lefelé mozog, akkor ez felmegy.
// 	Ha a CLOCKWISE általában felfelé halad, akkor ez lefelé lép.
//
//#define REVERSE_MENU_DIRECTION

//
// Ez az opció megfordítja a Kijelző képernyője EncoderJÉNEK irányát.
//
// Ha a CLOCKWISE általában BALRA mozog, akkor ez jobbra megy.
// Ha a CLOCKWISE általában JOBBRA mozog, akkor ez balra megy.
//
//#define REVERSE_SELECT_DIRECTION

//
// Egyéni tengely-hozzárendelés
//
// Adja hozzá az egyes tengelyekhez való homolós elemeket (Home X, Home Y és Home Z) az LCD menübe.
//
//#define INDIVIDUAL_AXIS_HOMING_MENU

//
// HANGSZÓRÓ / BUZZER
//
// Ha van hangszórója, amely hangot képes előállítani, itt engedélyezze.
// Marlin alapértelmezés szerint feltételezi, hogy van egy rögzített frekvenciájú hangjelző.
//
//#define SPEAKER

//
// Az UI visszacsatoló hang időtartama és frekvenciája.
// Állítsa ezeket 0-ra az audio visszacsatolás letiltásához az LCD menükben.
//
// Megjegyzés: Tesztelje az audiokimenetet a G-kóddal:
// M300 S <frekvencia Hz> P <időtartam ms>
//
//#define LCD_FEEDBACK_FREQUENCY_DURATION_MS 2
//#define LCD_FEEDBACK_FREQUENCY_HZ 5000

//=============================================================================
//======================== LCD / vezérlő kiválasztása =========================
//========================   (karakter alapú LCD-k)   =========================
//=============================================================================

//
// RepRapDiscount intelligens vezérlő.
// http://reprap.org/wiki/RepRapDiscount_Smart_Controller
//
// Megjegyzés: Általában fehér PCB-vel értékesítik.
//
//#define REPRAP_DISCOUNT_SMART_CONTROLLER

//
// Eredeti RADDS LCD kijelző+Encoder+SDCardReader
// http://doku.radds.org/dokumentation/lcd-display/
//
//#define RADDS_DISPLAY

//
// ULTIMAKER vezérlő.
//
//#define ULTIMAKERCONTROLLER

//
// ULTIPANEL a Thingiverse-en látható.
//
//#define ULTIPANEL

//
// PanelOne a T3P3-tól (via RAMPS 1.4 AUX2/AUX3)
// http://reprap.org/wiki/PanelOne
//
//#define PANEL_ONE

//
// GADGETS3D G3D LCD / SD vezérlő
// http://reprap.org/wiki/RAMPS_1.3/1.4_GADGETS3D_Shield_with_Panel
//
// Megjegyzés: Általában kék PCB-vel értékesítik.
//
//#define G3D_PANEL

//
// RigidBot Panel V1.0
// http://www.inventapart.com/
//
//#define RIGIDBOT_PANEL

//
// Makeboard 3D nyomtató alkatrészek 3D nyomtató Mini Display 1602 Mini vezérlő
// https://www.aliexpress.com/item/32765887917.html
//
//#define MAKEBOARD_MINI_2_LINE_DISPLAY_1602

//
// ANET és Tronxy 20x4 vezérlő
//
//#define ZONESTAR_LCD            // Szükség van az ADC_KEYPAD_PIN hozzárendelésére egy analóg PIN-khoz.
                                  // Ez az LCD ismert, hogy érzékeny az elektromos zavarokra,
                                  // amely becsavarja a képernyőt. Bármely gomb megnyomásával törli a képet.
                                  // Ez egy LCD2004 kijelző 5 analóg gombbal.

//
// Általános 16x2, 16x4, 20x2 vagy 20x4 karakter alapú LCD.
//
//#define ULTRA_LCD

//=============================================================================
//======================== LCD / vezérlő kiválasztása =========================
//=====================  (I2C és Shift-Register LCD-k)   ======================
//=============================================================================

//
// VEZÉRLŐ TÍPUSA: I2C
//
// Megjegyzés: Ezeknek a vezérlőknek az Arduino LiquidCrystal_I2C telepítését kell telepíteniük
// könyvtár. További információ: https://github.com/kiyoshigawa/LiquidCrystal_I2C
//

//
// Elefu RA Board vezérlőpult
// http://www.elefu.com/index.php?route=product/product&product_id=53
//
//#define RA_CONTROL_PANEL

//
// Sainsmart (YwRobot) LCD kijelzők
//
// Ehhez szükséges F.Malpartida LiquidCrystal_I2C könyvtára
// https://bitbucket.org/fmalpartida/new-liquidcrystal/wiki/Home
//
//#define LCD_SAINSMART_I2C_1602
//#define LCD_SAINSMART_I2C_2004

//
// Általános LCM1602 LCD adapter
//
//#define LCM1602

//
// PANELOLU2 LCD állapotjelző LED-ekkel,
// külön kódoló és kattintson a bemenetekre.
//
// Megjegyzés: Ehhez a vezérlőhöz az Arduino LiquidTWI2 v1.2.3 vagy újabb verziójára van szükség.
// További információ: https://github.com/lincomatic/LiquidTWI2
//
// Megjegyzés: A PANELOLU2 encoder click bemenete közvetlenül csatlakoztatható
// egy pin (ha a BTN_ENC értéke! = -1) vagy az I2C átolvasása (amikor BTN_ENC == -1).
//
//#define LCD_I2C_PANELOLU2

//
// Panucatt VIKI LCD állapotjelző LED-ekkel,
// integrált click & L/R/U/D gombok, külön encoder bemenetek.
//
//#define LCD_I2C_VIKI

//
// VEZÉRLŐ TÍPUSA: Váltó regiszter panelek
//

//
// 2 vezetékes nem reteszelő LCD SR a https://goo.gl/aJJ4sH webhelyről
// LCD konfiguráció: http://reprap.org/wiki/SAV_3D_LCD
//
//#define SAV_3DLCD

//
// 3-vezetékes SR LCD sávval a 74HC4094 használatával
// https://github.com/mikeshub/SailfishLCD
// A kódot közvetlenül a Sailfish-ből használja
//
//#define FF_INTERFACEBOARD

//=============================================================================
//=======================   LCD / vezérlő kiválasztása  =======================
//=========================     ((grafikus LCD-k)      ========================
//=============================================================================

//
// VEZÉRLŐ TÍPUSA: Grafikus 128x64 (DOGM)
//
// FONTOS: Az U8glib könyvtár szükséges a grafikus megjelenítéshez!
// https://github.com/olikraus/U8glib_Arduino
//

//
// RepRapDiscount FULL GRAPHIC Smart Controller
// http://reprap.org/wiki/RepRapDiscount_Full_Graphic_Smart_Controller
//
//#define REPRAP_DISCOUNT_FULL_GRAPHIC_SMART_CONTROLLER

//
// ReprapWorld Graphical LCD
// https://reprapworld.com/?products_details&products_id/1218
//
//#define REPRAPWORLD_GRAPHICAL_LCD

//
// Aktiválja az egyiket, ha Panucatt-eszközökkel rendelkezik
// Viki 2.0 vagy mini Viki grafikus LCD-vel
// http://panucatt.com
//
//#define VIKI2
//#define miniVIKI

//
// MakerLab Mini Panel grafikával
// vezérlő és SD támogatás - http://reprap.org/wiki/Mini_panel
//
//#define MINIPANEL

//
// MaKr3d Makr-panel grafikus vezérlővel és SD támogatással.
// http://reprap.org/wiki/MaKr3d_MaKrPanel
//
//#define MAKRPANEL

//
// Adafruit ST7565 Full Graphic Controller.
// https://github.com/eboston/Adafruit-ST7565-Full-Graphic-Controller/
//
//#define ELB_FULL_GRAPHIC_CONTROLLER

//
// BQ LCD intelligens vezérlő, szállító
// alapértelmezett a BQ Hephestos 2 és a Witbox 2 esetén.
//
//#define BQ_LCD_SMART_CONTROLLER

//
// Cartesio UI
// http://mauk.cc/webshop/cartesio-shop/electronics/user-interface
//
//#define CARTESIO_UI

//
// LCD a Melzi kártya számára grafikus LCD-vel
//
//#define LCD_FOR_MELZI

//
// Eredeti ultravezérlő az Ultimaker 2 nyomtatóból, SSD1309 I2C kijelzővel és kódolóval
// https://github.com/Ultimaker/Ultimaker2/tree/master/1249_Ulticontroller_Board_(x1)
//
//#define ULTI_CONTROLLER

//
// MKS MINI12864 grafikus vezérlővel és SD támogatással
// https://reprap.org/wiki/MKS_MINI_12864
//
//#define MKS_MINI_12864

//
// A MINI12864 grafikus vezérlő FYSETC változata SD támogatással
// https://wiki.fysetc.com/Mini12864_Panel/
//
//#define FYSETC_MINI_12864_X_X    // Írja be a C/D/E/F értéket. Alapértelmezés szerint nincs hangolható RGB háttérvilágítás
//#define FYSETC_MINI_12864_1_2    // Type C/D/E/F. Egyszerű RGB háttérvilágítás (mindig bekapcsolva)
//#define FYSETC_MINI_12864_2_0    // Írja be az A/B értéket. Diszkrét RGB háttérvilágítás
//#define FYSETC_MINI_12864_2_1    // Írja be az A/B értéket. Neopixel RGB háttérvilágítás
//#define FYSETC_GENERIC_12864_1_1 // Nagyobb kijelző alapvető BE/KI háttérvilágítással.

//
// A Creality CR-10 gyári kijelzője
// https://www.aliexpress.com/item/32833148327.html
//
// Ez RAMPS-kompatibilis egyetlen 10 pólusú csatlakozóval.
// (CR-10 tulajdonosok számára, akik ki akarják cserélni a Melzi Creality táblát, de megtartják a kijelzőt)
//
//#define CR10_STOCKDISPLAY

//
// Ender-2 OEM kijelző, az MKS_MINI_12864 változata
//
//#define ENDER2_STOCKDISPLAY

//
// ANET and Tronxy Graphical Controller
//
// Anet 128x64 full graphics lcd with rotary encoder as used on Anet A6
// A clone of the RepRapDiscount full graphics display but with
// different pins/wiring (see pins_ANET_10.h).
//
//#define ANET_FULL_GRAPHICS_LCD

//
// AZSMZ 12864 LCD SD-vel
// https://www.aliexpress.com/item/32837222770.html
//
//#define AZSMZ_12864

//
// Silvergate GLCD vezérlő
// http://github.com/android444/Silvergate
//
//#define SILVER_GATE_GLCD_CONTROLLER

//=============================================================================
//==============================  OLED kijelzők  ==============================
//=============================================================================

//
// SSD1306 OLED teljes grafikus általános kijelző
//
//#define U8GLIB_SSD1306

//
// A SAV OLEd LCD modul támogatása akár SSD1306, akár SH1106 alapú LCD modulokkal
//
//#define SAV_3DGLCD
#if ENABLED(SAV_3DGLCD)
  #define U8GLIB_SSD1306
  //#define U8GLIB_SH1106
#endif

//
// TinyBoy2 128x64 OLED / Encoder Panel
//
//#define OLED_PANEL_TINYBOY2

//
// MKS OLED 1.3" 128 × 64 FULL GRAPHICS CONTROLLER
// http://reprap.org/wiki/MKS_12864OLED
//
// Apró, de nagyon éles OLED kijelző
//
//#define MKS_12864OLED          // Az SH1106 vezérlőt használja (alapértelmezett)
//#define MKS_12864OLED_SSD1306  // Az SSD1306 vezérlőt használja

//
// Einstart S OLED SSD1306
//
//#define U8GLIB_SH1106_EINSTART

//
// Overlord OLED kijelző / vezérlő i2c hangjelzővel és LED-ekkel
//
//#define OVERLORD_OLED

//=============================================================================
//==========  Meghosszabbítható felhasználói felület megjeleníti  =============
//=============================================================================

//
// DGUS érintőképernyő DWIN operációs rendszerrel. (Válasszon.)
//
//#define DGUS_LCD_UI_ORIGIN
//#define DGUS_LCD_UI_FYSETC
//#define DGUS_LCD_UI_HIPRECY

//
// Érintőképernyős LCD a Malyan M200 nyomtatókhoz
//
//#define MALYAN_LCD

//
// Érintse meg az FTDI EVE (FT800 / FT810) felhasználói felületének megjelenítését
// Az összes konfigurációs beállítást lásd a Configuration_adv.h oldalon.
//
//#define TOUCH_UI_FTDI_EVE

//
// Harmadik fél által gyártó vagy gyártó által testreszabott vezérlő interfészek.
// A forrásokat az 'src / lcd / extensible_ui' mappába kell telepíteni.
//
//#define EXTENSIBLE_UI

//=============================================================================
//=============================== Graphical TFTs ==============================
//=============================================================================

//
// FSMC kijelző (MKS Robin, Alfawise U20, JGAurora A5S, REXYZ A1 stb.)
//
//#define FSMC_GRAPHICAL_TFT

//=============================================================================
//=============================  Egyéb vezérlők  ==============================
//=============================================================================

//
// ADS7843 / XPT2046 ADC érintőképernyő, például ILI9341 2.8
//
//#define TOUCH_BUTTONS
#if ENABLED(TOUCH_BUTTONS)
  #define BUTTON_DELAY_EDIT  50 // (ms) Gomb ismételt késleltetés a szerkesztési képernyőknél
  #define BUTTON_DELAY_MENU 250 // (ms) Gomb ismételt késleltetés a menüknél

  #define XPT2046_X_CALIBRATION   12316
  #define XPT2046_Y_CALIBRATION  -8981
  #define XPT2046_X_OFFSET       -43
  #define XPT2046_Y_OFFSET        257
#endif

//
// RepRapWorld REPRAPWORLD_KEYPAD v1.1
// http://reprapworld.com/?products_details&products_id=202&cPath=1591_1626
//
//#define REPRAPWORLD_KEYPAD
//#define REPRAPWORLD_KEYPAD_MOVE_STEP 10.0 // (mm) Distance to move per key-press

//=============================================================================
//============================ Extra szolgáltatások ===========================
//=============================================================================

// @section extrák

// Növelje a FAN PWM frekvenciáját. Eltávolítja a PWM zajt, de növeli a FET / Arduino fűtését
//#define FAST_PWM_FAN

// Használja a PWM szoftvert a ventilátor vezérléséhez, mint a fűtőkészülékekhez. Ez nagyon alacsony frekvenciát használ
// ami nem olyan idegesítő, mint a hardver PWM esetén. Másrészt, ha ez a frekvencia
// túl alacsony, akkor a SOFT_PWM_SCALE növekedést is meg kell növelnie.
//#define FAN_SOFT_PWM

// Ha ezt egyre növeli, megduplázódik a szoftver PWM frekvenciája,
// befolyásolja a fűtőberendezéseket és a ventilátort, ha a FAN_SOFT_PWM engedélyezve van.
// A kontroll felbontása azonban minden egyes növekedésnél felére csökken;
// nulla értéknél 128 hatékony vezérlési pozíció van.
//: [0,1,2,3,4,5,6,7]
#define SOFT_PWM_SCALE 0

// Ha a SOFT_PWM_SCALE értéke 0-nál nagyobb értékre van állítva, akkor a vonalvezetés lehetséges
// használható a kapcsolódó felbontási veszteségek csökkentésére. Ha engedélyezve van,
// néhány PWM ciklus meg van feszítve, tehát átlagosan a kívánt
// elérik a munkaciklusot.
//#define SOFT_PWM_DITHER

// Hőmérsékleti állapotjelző LED-ek, amelyek megjelenítik a meleg hőmérsékletet és az ágy hőmérsékletét.
// Ha az összes melegítés, az ágy hőmérséklete és a célhőmérséklet 54 ° C alatt van
// akkor a KÉK led világít. Egyébként a RED led be van kapcsolva. (1C hiszterézis)
//#define TEMP_STAT_LEDS

// A SkeinForge rossz ív g-kódokat küld, ha az Arc Point szalag-eljárásként történik
//#define SF_ARC_FIX

// A BariCUDA Paste Extruder támogatása
//#define BARICUDA

// A BlinkM / CyzRgb támogatása
//#define BLINKM

// A PCA9632 PWM LED driver támogatása
//#define PCA9632

// Támogatás a PCA9533 PWM LED driverhez
// https://github.com/mikeshub/SailfishRGB_LED
//#define PCA9533

/**
 * RGB LED / LED szalagvezérlés
 *
 * Engedélyezze az 5 V digitális pinekhez csatlakoztatott RGB LED támogatását, vagy
 * egy RGB szalag, amely digitális pinek által vezérelt MOSFET-ekhez csatlakozik.
 *
 * Hozzáadja az M150 parancsot a LED (vagy LED-sáv) színének beállításához.
 * Ha a pinek PWM képesek (például 4, 5, 6, 11), akkor a tartomány:
 * A fényerő 0 és 255 között állítható.
 * A Neopixel LED esetében általános fényerő-paraméter is rendelkezésre áll.
 *
 * *** VIGYÁZAT ***
 * A LED-csíkokhoz MOSFET-chipet kell használni a PWM vonalak és a LED-ek között,
 * mivel az Arduino nem képes kezelni a LED-ek által igényelt áramot.
 * Ezen óvintézkedés be nem tartása tönkreteheti Arduino-ját!
 * MEGJEGYZÉS: Külön 5V tápegységre van szükség! A Neopixel LED-nek szüksége van
 * nagyobb áram, mint az Arduino 5V lineáris szabályozó képes.
 * *** VIGYÁZAT ***
 *
 * LED típus. A következő két lehetőség közül csak az egyik engedélyezése.
 *
 */
//#define RGB_LED
//#define RGBW_LED

#if EITHER(RGB_LED, RGBW_LED)
  //#define RGB_LED_R_PIN 34
  //#define RGB_LED_G_PIN 43
  //#define RGB_LED_B_PIN 35
  //#define RGB_LED_W_PIN -1
#endif

// Támogatás az Adafruit Neopixel LED illesztőprogramhoz
//#define NEOPIXEL_LED
#if ENABLED(NEOPIXEL_LED)
  #define NEOPIXEL_TYPE   NEO_GRBW // NEO_GRBW / NEO_GRB - négy / három csatornás illesztőprogram típus (az Adafruit_NeoPixel.h fájlban definiálva)
  #define NEOPIXEL_PIN     4       // LED pin
  //#define NEOPIXEL2_TYPE NEOPIXEL_TYPE
  //#define NEOPIXEL2_PIN    5
  #define NEOPIXEL_PIXELS 30       // A LED-ek száma a szalagban, 2 csíkból nagyobb, ha 2 neopixel csíkot használnak
  #define NEOPIXEL_IS_SEQUENTIAL   // Hőmérséklet-változás szekvenciális kijelzője - LED világít. Tilos letiltani az összes LED egyszerre cserélését.
  #define NEOPIXEL_BRIGHTNESS 127  // Kezdeti fényerő (0-255)
  //#define NEOPIXEL_STARTUP_TEST  // Átcsavarja a színeket indításkor

  // Statikus (háttér) világításhoz használjon egyetlen Neopixel LED-et
  //#define NEOPIXEL_BKGD_LED_INDEX  0               // A használandó LED indexe
  //#define NEOPIXEL_BKGD_COLOR { 255, 255, 255, 0 } // R, G, B, W
#endif

/**
 * Nyomtató esemény LED-ek
 *
 * A nyomtatás során a LED-ek tükrözik a nyomtató állapotát:
 *
 * 	- Fokozatosan váltson kékről lila színre, amint a fűtött ágy eléri a kívánt hőmérsékletet
 * 	- Fokozatosan váltson lilaról vörösre, amint a meleg hőmérséklete felmeleged
 * 	- Váltson fehérre, hogy megvilágítsa a munkafelületet
 * 	- Zöldre váltás, ha a nyomtatás befejeződött
 * 	- Kapcsolja ki, miután a nyomtatás befejeződött és a felhasználó egy gombot nyomott
 */
#if ANY(BLINKM, RGB_LED, RGBW_LED, PCA9632, PCA9533, NEOPIXEL_LED)
  #define PRINTER_EVENT_LEDS
#endif

/**
 * R/C SERVO támogatás
 * TrinityLabs szponzorálja, codexmas átdolgozta
 */

/**
 * Szervoszám
 *
 * Néhány szervóhoz kapcsolódó opcióhoz a NUM_SERVOS automatikusan bekapcsol.
 * Állítsa be kézzel, ha vannak olyan további szervók, amelyek kézi vezérlést igényelnek.
 * Hagyja meghatározatlanul vagy állítsa 0-ra a szervo alrendszer teljes letiltásához.
 */
//#define NUM_SERVOS 3 // Servo index starts with 0 for M280 command

// (ms) Késleltetés a következő lépés indulása előtt, hogy a szervónak ideje legyen elérni a célszöget.
// 300ms jó érték, de kipróbálhat kevesebb késleltetést is.
// Ha a szervo nem éri el a kívánt helyet, akkor növelje meg.
#define SERVO_DELAY { 300 }

// Csak elektromos szervókat mozgás közben, ellenkező esetben hagyja ki a rázkódás megelőzése érdekében
//#define DEACTIVATE_SERVOS_AFTER_MOVE

// Engedélyezze a szervószög szerkesztését és mentését az EEPROM-ba
//#define EDITABLE_SERVO_ANGLES
